// ===== Motor del juego 1 vs 1 =====
const LW=2576,LH=1438,HOOP=[{x:366,y:1090},{x:2210,y:1090}],RIM_Z=298,BASE=.85;
const RA=[0,1,2,3,4,5,6,7].map(i=>'RA'+i),SPR=[0,1,2,3,4,5,6,7].map(i=>'RB'+i),RUN=[...RA,...SPR],
IDB=['ID1','ID2','ID4','ID2'],HOLD=['ID1','ID2','ID4','ID2'],NIDLE=['ID0','ID3','IH1','ID3'],DSH=['DS0','DS1','DS2','DS1'],WALKB=['WR1','WR2','WR3','WR5','WL0','WL1','WL3','WL4','WL5'],WALKALL=['WR0','WR1','WR2','WR4','WR5','WL0','WL1','WL2','WL4','WL5'],
XS=[[['CR0',5],['CR1',6],['CR2',7],['CR1',6],['CR0',5]],[['CR0',4],['BB0',8],['BB1',8],['CR2',6],['CR1',5]],[['CR1',5],['SP0',9],['BB1',6],['SP0',6],['CR2',5],['CR0',5]]],XL=XS.map(q=>q.reduce((a,b)=>a+b[1],0)),CEL=['CE0','CE1','CE3','CE2'];
(function(){const q=WALKALL;for(let i=0;i<q.length;i++){const f=FR[q[i]];if(f.ball)continue;let a=null,b=null;
 for(let k=1;k<q.length&&!a;k++){const g=FR[q[(i-k+q.length)%q.length]];if(g.ball)a=g.ball}
 for(let k=1;k<q.length&&!b;k++){const g=FR[q[(i+k)%q.length]];if(g.ball)b=g.ball}
 f.ball=[(a[0]+b[0])/2,(a[1]+b[1])/2,(a[2]+b[2])/2]}})();
const LGP={"WR0":[-28.0,-3.8],"WR1":[-29.0,-20.6],"WR2":[-25.0,-21.7],"WR4":[-30.0,-14.5],"WR5":[-31.0,-16.9],"WL0":[-22.0,6.2],"WL1":[-23.0,2.5],"WL2":[-22.0,-4.6],"WL4":[-29.0,-7.7],"WL5":[-22.0,-5.8],"RA0":[-41.0,-49.6],"RA1":[-40.0,-53.2],"RA2":[-44.0,-50.1],"RA3":[-40.0,-52.1],"RA4":[-44.0,-50.2],"RA5":[-40.0,-47.3],"RA6":[-37.0,-59.0],"RA7":[-38.0,-53.1],"RB0":[-45.0,-39.5],"RB1":[-47.0,-40.9],"RB2":[-48.0,-43.9],"RB3":[-47.0,-38.1],"RB4":[-44.0,-41.6],"RB5":[-46.0,-44.4],"RB6":[-46.0,-44.3],"RB7":[-47.0,-39.4]};
function drawLegs(g,hx,hy,cy,gt,sk){const A=[28,40,44][gt],H=[8,14,18][gt],L=-hy+12,L1=L*.52,L2=L*.6,px=hx,py=hy-10;
 g.lineCap=g.lineJoin='round';
 for(const i of[1,0]){const s=(cy+i*.5)%1;let fx,fy;
  if(s<.55){fx=A*(1-2*s/.55);fy=0}else{const t=(s-.55)/.45;fx=-A+2*A*t;fy=-H*Math.sin(Math.PI*t)}
  const tx=hx+fx,ty=fy-6,dx=tx-px,dy=ty-py,d=Math.min(Math.hypot(dx,dy),(L1+L2)*.985),an=Math.atan2(dy,dx);
  const ca=Math.max(-1,Math.min(1,(L1*L1+d*d-L2*L2)/(2*L1*d))),a=Math.acos(ca);
  const kx=px+L1*Math.cos(an-a),ky=py+L1*Math.sin(an-a),ax=px+d*Math.cos(an),ay=py+d*Math.sin(an);
  g.beginPath();g.moveTo(px,py);g.lineTo(kx,ky);g.lineTo(ax,ay);
  g.strokeStyle='#2a1620';g.lineWidth=14;g.stroke();g.strokeStyle=sk;g.lineWidth=9.5;g.stroke();
  if(i){g.strokeStyle='rgba(0,0,0,.28)';g.stroke()}
  g.save();g.translate(ax,ay);g.rotate(Math.max(-.5,Math.min(.5,(fy<0?-.25:.1)+(s>.45&&s<.55?.3:0))));
  g.fillStyle='#1d1a40';g.beginPath();g.roundRect(-9,-6,27,13,5);g.fill();
  g.fillStyle=i?'#3b3a86':'#4a49a8';g.beginPath();g.roundRect(-7.5,-5,24,8,4);g.fill();
  g.fillStyle='#f2f2f2';g.fillRect(-8,4,26,2.5);g.restore()}}
const CYL=[WALKALL,RA,SPR].map(q=>{let bi=0,by=-1e9;q.forEach((n,i)=>{const b=FR[n].ball;if(b&&b[1]>by){by=b[1];bi=i}});return(bi+.5)/q.length});
const cv=$('#gameCanvas'),ctx=cv.getContext('2d');
let S=1,offY=0,dpr=1;
function resize(){dpr=Math.min(2.5,devicePixelRatio||1);cv.width=Math.round(innerWidth*dpr);cv.height=Math.round(innerHeight*dpr)}
addEventListener('resize',resize);resize();
const IM={};
function loadImgs(){return Promise.all(['stadium.jpg','body.png','jersey.png','skin.png','heads.png','ball.png'].map(n=>new Promise(r=>{const i=new Image();i.onload=()=>r();i.onerror=()=>r();i.src='assets/'+n;IM[n.split('.')[0]]=i})))}
// ---- sprites ----
const mkc=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c};
const skinCache={};
function skinOf(id){if(skinCache[id])return skinCache[id];let col='#d9a070';
 try{const c=mkc(HM.cw,HM.ch),g=c.getContext('2d');g.drawImage(IM.heads,(id%HM.cols)*HM.cw,((id/HM.cols)|0)*HM.ch,HM.cw,HM.ch,0,0,HM.cw,HM.ch);
  const d=g.getImageData(HM.ax-15,HM.ay-50,30,22).data,R=[],G=[],B=[];
  for(let i=0;i<d.length;i+=4){if(d[i+3]<200)continue;const m=(d[i]+d[i+1]+d[i+2])/3;if(m<80||m>240||d[i]<d[i+1])continue;R.push(d[i]);G.push(d[i+1]);B.push(d[i+2])}
  const md=a=>a.sort((x,y)=>x-y)[a.length>>1];if(R.length>20)col=`rgb(${md(R)},${md(G)},${md(B)})`}catch(e){}
 return skinCache[id]=col}
const tintCache=new Map();
function tinted(jc,sc){const key=jc+'|'+sc;let c=tintCache.get(key);if(c)return c;
 const W=IM.body.width,H=IM.body.height;c=mkc(W,H);const x=c.getContext('2d');x.drawImage(IM.body,0,0);
 for(const[img,col]of[[IM.jersey,jc],[IM.skin,sc]]){const t=mkc(W,H),tx=t.getContext('2d');tx.drawImage(img,0,0);tx.globalCompositeOperation='multiply';tx.fillStyle=col;tx.fillRect(0,0,W,H);tx.globalCompositeOperation='destination-in';tx.drawImage(img,0,0);x.drawImage(t,0,0)}
 if(tintCache.size>7)tintCache.delete(tintCache.keys().next().value);tintCache.set(key,c);return c}
function gaitOf(ph,ratio,an){if(ratio>0)return{z:0,rot:.5+.8*Math.min(1.2,ratio),sx:1,sy:1};return{z:0,rot:0,sx:1,sy:1+.014*Math.sin(an*.09)}}
function ballImg(g,cx,cy,r){g.drawImage(IM.ball,cx-r,cy-r,2*r,2*r)}
const lrp=(a,b,u)=>[a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u],RIG_ST=['idle','shoot','dunk','block','steal','shove','cross','win','lose','fall'];
function rigBall(p){const t=p.tt;
 if(p.st==='shoot')return t<8?lrp([30,-60],[20,-52],t/8):t<18?lrp([20,-52],[14,-118],(t-8)/10):t<30?lrp([14,-118],[26,-140],(t-18)/12):[26,-140];
 if(p.st==='dunk'){const u=t-p.dk0,k=p.dkind,top=k?[46,-156]:[34,-146];if(k===3&&u>=6&&u<14)return[-6,-162];if(k===4&&u>=3&&u<20){const a=(u-3)/17*6.2832;return[10+34*Math.sin(a),-125-30*Math.cos(a)]}return u<0?[30,-62]:u<5?lrp([30,-62],[20,-96],u/5):u<12?lrp([20,-96],[14,-140],(u-5)/7):u<20?lrp([14,-140],top,(u-12)/8):top}
 return null}
function rigOf(p,dr){const t=p.tt,B=G.B,s=p.st,o={mv:p.mv,gait:p.gait||0,cy:p.cyc||0,an:p.an,ball:B.h===p,dr,def:!!B.h&&B.h!==p&&!p.mv};
 const pose=(ln,cr,h0,h1,f,b,run)=>{o.ps={ln,cr,h:[h0,h1],f,b};if(run){o.mv=true;o.gait=2;o.cy=(t/14)%1;o.ps.f=null}};
 if(p.gd&&s==='idle'&&G.B.h&&G.B.h!==p){const w=p.mv?5*Math.sin(p.an*.45):0;pose(.12,10,[48,-104+5*Math.sin(p.an*.2)],[-26,-96],[[16+w,0],[-14-w,0]],null)}
 else if(s==='shoot'){const b=rigBall(p),c=t<8?10*t/8:t<18?10*(1-(t-8)/10):0,hd=t<30;
  pose(CH[p.id].pw==='CORONA'?-.26:p.pw?-.2:.04,c,hd?[b[0]+6,b[1]+9]:[30,t<44?-150:-70],hd?[b[0]-10,b[1]+13]:[22,t<44?-142:-70],t>4&&t<44?[[10,-7],[-8,-4]]:null,b)}
 else if(s==='dunk'){const u=t-p.dk0,b=rigBall(p),k=p.dkind||0;
  if(u<0)pose(.3,0,[b[0]+4,b[1]+2],[8,-70],null,b,1);
  else{const hg=u>=20;pose(u<5?.15:u<14?-.04:.2,u<5?12*u/5:0,hg?[b[0]+4,b[1]+14]:[b[0]+6,b[1]+9],k===1?[-16,-128]:hg?[-10,-120]:[b[0]-10,b[1]+13],k>2?[[26,-24],[-18,-12]]:[[22,-17],[-14,-7]],b);if(k===5&&u>=4&&u<30)o.ps.sx=Math.cos(6.2832*(u-4)/26)}}
 else if(s==='block'){const up=t>5;pose(up?-.03:.1,up?0:8,up?[22,-180]:[34,-92],up?[8,-174]:[26,-96],up?[[8,-6],[-6,-4]]:null)}
 else if(s==='steal')pose(.28,8,[50+14*Math.sin(t*.5),-62],[-6,-58],[[18,0],[-10,0]]);
 else if(s==='shove')pose(.22,6,[50,-82],[44,-90],[[14,0],[-12,0]]);
 else if(s==='win'){const v=p.id%4,j=Math.sin(t*.25);
  if(v===0)pose(-.05,0,[28,-165+8*j],[10,-165-8*j],null);else if(v===1)pose(.05,0,[20,-124],[-6,-124],[[10,0],[-10,0]]);
  else if(v===2)pose(.1,0,[40,-170],[-4,-60],null);else pose(0,4+3*j,[12,-86+6*j],[-2,-86-6*j],[[8,0],[-8,0]])}
 else if(s==='lose')pose(.35,6,[14,-36],[-2,-36],[[8,0],[-8,0]]);
 else if(s==='fall'){const th=t<12?.7*t/12:t<28?.7+.75*(t-12)/16:t<112?1.45:t<134?1.45-.95*(t-112)/22:.5*(1-(t-134)/12);pose(0,0,[26,-52],[14,-44],[[16,-10],[-4,-4]],null);o.ps.rot=Math.max(0,th)}
 else if(s==='cross'){const u=t/(p.cl||30),k=p.vk|0,TW=6.2832,c=Math.cos(TW*u),lo=-23-16*(.5+.5*Math.cos(TW*2*u));
  let b,f=null,cr=0,ln=.12,run=0,h1=[-4,-66],h0=null;
  if(k===0){b=[24+20*c,lo];run=1;ln=.12+.1*Math.sin(TW*u)}
  else if(k===1){b=[34-60*Math.sin(Math.PI*u),-23-10*Math.sin(Math.PI*u)];f=[[20,0],[-18,0]];cr=8;ln=.2}
  else if(k===2){b=[-24,-62+8*Math.cos(TW*2*u)];h1=[-22,b[1]+4];h0=[20,-66];run=1}
  else if(k===3){b=[30,-62];run=1}
  else{b=[30,lo];f=[[12,0],[-12,0]];cr=12*Math.sin(Math.PI*u);ln=.2-.25*u}
  pose(ln,cr,h0||[b[0]-2,b[1]-18],h1,f,b,run);if(k===3)o.ps.sx=c}
 return o}
function drawRigFig(g,x,y,sc,flip,col,hid,o){
 const hh=CH[hid].h||1,sk=skinOf(hid),OL='#1a1020',mv=o.mv,gt=o.gait,cy=o.cy,TW=6.2832,A=[20,28,32][gt],H=[8,14,18][gt],cr=o.ps?o.ps.cr:o.def?10:0;
 const bob=o.ps?0:mv?[2.5,5,6][gt]*Math.abs(Math.sin(cy*TW)):1.2*Math.sin(o.an*.07);
 const ln=o.ps?o.ps.ln:mv?[.07,.18,.3][gt]:(o.ball?.1:o.def?.14:.02),cs=Math.cos(ln),sn=Math.sin(ln),hy=-56+cr-bob;
 const rot=(a,b)=>[a*cs-b*sn,hy+a*sn+b*cs];
 g.save();g.translate(x,y);g.scale(flip*sc*1.1*hh,sc*1.1*hh);if(o.ps&&o.ps.sx!=null)g.scale(o.ps.sx,1);if(o.ps&&o.ps.rot){g.translate(-10*Math.sin(o.ps.rot),-12*Math.sin(o.ps.rot));g.rotate(-o.ps.rot)}g.lineCap=g.lineJoin='round';
 const line=(p,w,c)=>{g.beginPath();g.moveTo(p[0][0],p[0][1]);for(let i=1;i<p.length;i++)g.lineTo(p[i][0],p[i][1]);g.lineWidth=w;g.strokeStyle=c;g.stroke()};
 const limb=(p,w,c)=>{line(p,w+4,OL);line(p,w,c)};
 const leg=i=>{let fx,fy,s=0;
  if(o.ps&&o.ps.f){fx=o.ps.f[i][0];fy=o.ps.f[i][1]}else if(mv){s=(cy+i*.5)%1;if(s<.55){fx=A*(1-2*s/.55);fy=0}else{const t=(s-.55)/.45;fx=-A+2*A*t;fy=-H*Math.sin(Math.PI*t)}}
  else{fx=(i?-1:1)*(o.def?17:8);fy=0}
  const px=i?-2:2,py=hy+6,L=27,dx=fx-px,dy=fy-5-py,d=Math.min(Math.hypot(dx,dy),2*L*.985),an=Math.atan2(dy,dx),a=Math.acos(d/(2*L));
  const l={px,py,kx:px+L*Math.cos(an-a),ky:py+L*Math.sin(an-a),ax:px+d*Math.cos(an),ay:py+d*Math.sin(an),fy};
  limb([[l.px,l.py],[l.kx,l.ky],[l.ax,l.ay]],10,sk);if(i)line([[l.px,l.py],[l.kx,l.ky],[l.ax,l.ay]],10,'rgba(0,0,0,.25)');
  const ux=l.kx-l.ax,uy=l.ky-l.ay,m=Math.hypot(ux,uy)||1;limb([[l.ax,l.ay],[l.ax+ux/m*11,l.ay+uy/m*11]],10,'#f4f4f4');
  g.save();g.translate(l.ax,l.ay);g.rotate(l.fy<0?-.3:.05);g.fillStyle='#f4f4f4';g.strokeStyle=OL;g.lineWidth=2.5;g.beginPath();g.roundRect(-8,-7,26,12,5);g.fill();g.stroke();g.fillStyle=col;g.fillRect(-2,-3,12,4);g.restore()};
 const S=rot(2,-37),dr=o.dr||[1,0],by=-23-37*dr[0],bx=30+dr[1]*(1-dr[0])+ln*25;
 const arm=i=>{let E,W;
  if(o.ps&&o.ps.h||i===0&&o.ball){const hh=o.ps&&o.ps.h?o.ps.h[i]:[bx-2,by-21],tx=hh[0],ty=hh[1],dx=tx-S[0],dy=ty-S[1],d=Math.min(Math.hypot(dx,dy),43),an=Math.atan2(dy,dx),a=Math.acos(d/44);
   E=[S[0]+22*Math.cos(an+a),S[1]+22*Math.sin(an+a)];W=[S[0]+d*Math.cos(an),S[1]+d*Math.sin(an)]}
  else{let al,bd;
   if(mv){const sw=[.45,.8,.95][gt];al=(i?1:-1)*Math.sin(cy*TW)*sw+.1;bd=[.3,1.2,1.4][gt]}
   else if(o.def){al=i?-.7:.9;bd=.3}else{al=i?-.15:.15;bd=.25}
   E=[S[0]+22*Math.sin(al),S[1]+22*Math.cos(al)];W=[E[0]+20*Math.sin(al+bd),E[1]+20*Math.cos(al+bd)]}
  limb([S,E,W],8,sk);limb([S,[S[0]+(E[0]-S[0])*.5,S[1]+(E[1]-S[1])*.5]],11,col);
  g.fillStyle=sk;g.strokeStyle=OL;g.lineWidth=2.5;g.beginPath();g.arc(W[0],W[1],5.5,0,7);g.fill();g.stroke()};
 arm(1);leg(1);leg(0);
 g.save();g.translate(0,hy);g.rotate(ln);g.lineWidth=2.5;g.strokeStyle=OL;
 g.beginPath();g.moveTo(-14,2);g.lineTo(14,2);g.lineTo(17,-38);g.quadraticCurveTo(0,-45,-17,-38);g.closePath();g.fillStyle=col;g.fill();g.stroke();
 g.beginPath();g.roundRect(-16,-4,32,20,6);g.fillStyle=col;g.fill();g.fillStyle='rgba(0,0,0,.28)';g.fill();g.stroke();
 g.fillStyle='#fff';g.fillRect(-15,12,30,3);g.restore();
 const N=rot(0,-42);g.save();g.translate(N[0],N[1]+2);g.rotate(ln*.3);g.scale(.7/hh,.7/hh);
 g.drawImage(IM.heads,(hid%HM.cols)*HM.cw,((hid/HM.cols)|0)*HM.ch,HM.cw,HM.ch,-HM.ax,-HM.ay,HM.cw,HM.ch);g.restore();
 if(o.ball){const pb=o.ps&&o.ps.b;ballImg(g,pb?pb[0]:bx,pb?pb[1]:by,23/hh)}
 arm(0);g.restore()}
function drawFig(g,fn,x,y,sc,flip,col,hid,ball,bpos,gt,dr,cyp){
 const f=FR[fn];g.save();g.translate(x,y-(gt?gt.z*sc:0));if(gt&&gt.rot)g.rotate(gt.rot*flip*Math.PI/180);const kk=f.k||1;g.scale(flip*sc*kk*(gt?gt.sx:1),sc*kk*(gt?gt.sy:1));
 const lg=cyp&&LGP[fn];if(lg){drawLegs(g,lg[1],lg[0],cyp[0],cyp[1],skinOf(hid));g.save();g.beginPath();g.rect(f.ox-4,f.oy-4,f.w+8,lg[0]-f.oy+4);g.clip();g.drawImage(tinted(col,skinOf(hid)),f.sx,f.sy,f.w,f.h,f.ox,f.oy,f.w,f.h);g.restore()}else g.drawImage(tinted(col,skinOf(hid)),f.sx,f.sy,f.w,f.h,f.ox,f.oy,f.w,f.h);
 const bb=ball?(bpos||f.ball):null,back=fn==='LU1'&&false;
 g.save();g.translate(f.chin[0],f.chin[1]);g.rotate(f.rot*Math.PI/180);g.scale(f.hs,f.hs);
 g.drawImage(IM.heads,(hid%HM.cols)*HM.cw,((hid/HM.cols)|0)*HM.ch,HM.cw,HM.ch,-HM.ax,-HM.ay,HM.cw,HM.ch);g.restore();
 if(bb){let by=bb[1],bx=bb[0];if(dr!=null){const fl=-bb[2];by=fl+(bb[1]-fl)*dr[0];bx+=dr[1]*(1-dr[0])}ballImg(g,bx,by,bb[2])}g.restore()}
// ---- helpers de UI ----
const figC={};
function figImg(id,col){col=col||CH[id].jc;const k=id+'|'+col;if(figC[k])return figC[k];const c=mkc(176,196),g=c.getContext('2d');
 drawRigFig(g,88,192,.72,1,col,id,{mv:false,gait:0,cy:0,an:0,ball:false,dr:null,def:false});return figC[k]=c.toDataURL()}
const portrait=(id,sc=1,col)=>`<div class="hd" style="background-image:url(${figImg(id,col)});background-size:100% 100%;${sc!=1?`transform:scale(${sc});transform-origin:top left;`:''}"></div>`;
function hudPortrait(el,id,col){el.style.backgroundImage=`url(${figImg(id,col)})`;el.style.backgroundRepeat='no-repeat';el.style.backgroundSize='auto 190%';el.style.backgroundPosition='50% 6%'}
const prevs=[];
function mountPreviews(root){root.querySelectorAll('canvas[data-id]').forEach(c=>{if(!prevs.find(p=>p.c===c))prevs.push({c,id:+c.dataset.id,col:c.dataset.col})});drawPreviews()}
let pf=0;function drawPreviews(){pf++;for(let i=prevs.length-1;i>=0;i--){const p=prevs[i];if(!p.c.isConnected){prevs.splice(i,1);continue}if(!p.c.offsetParent)continue;
 const g=p.c.getContext('2d');g.clearRect(0,0,300,300);const ph=pf*.3;drawRigFig(g,150,285,.95,1,p.col,p.id,{mv:true,gait:1,cy:(ph*.07)%1,an:pf,ball:true,dr:[Math.abs(Math.cos(ph*.45)),6]})}}
setInterval(drawPreviews,95);
function statBars(s){return SK.map(k=>`<div class="stat"><b>${SN[k]}</b><i><u style="width:${s[k]}%"></u></i><span>${s[k]}</span></div>`).join('')}
function cardHTML(id,o,col,extra=''){const c=CH[id],R=RAR[c.rar],s=statsOf(id,o.lvl,o.st,o.mul||1);
 return `<div class="pcard" style="--rc:${R.c}"><div class="ovr">${ovrOf(s)}<small>OVR</small></div><canvas width="300" height="300" data-id="${id}" data-col="${col||c.jc}"></canvas>
 <div class="nm">${c.name}</div><div class="rr">★ ${R.k} · ${c.pos} · ${c.pw} · ${c.title||ARN[c.arch]}</div><div class="lv">Nv ${o.lvl} ${'★'.repeat(o.st)}${'☆'.repeat(MAXST-o.st)}</div>${statBars(s)}${extra}</div>`}
// ---- audio ----
let AC=null;function sfx(t){if(!save.snd)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const T={bounce:[[180,.05,'square',.04]],swish:[[880,.08,'triangle',.08],[1320,.12,'triangle',.08]],dunk:[[110,.2,'sawtooth',.12],[70,.3,'square',.1]],steal:[[500,.06,'square',.06],[300,.1,'square',.06]],fall:[[260,.1,'sawtooth',.07],[120,.25,'sawtooth',.07]],buzz:[[140,.7,'sawtooth',.14]],block:[[300,.05,'square',.1],[160,.15,'square',.08]],card:[[600,.08,'triangle',.08],[900,.12,'triangle',.08],[1200,.2,'triangle',.08]],legend:[[523,.12,'square',.08],[659,.12,'square',.08],[784,.12,'square',.08],[1047,.4,'square',.1]],perfect:[[1200,.06,'triangle',.09],[1600,.1,'triangle',.09]]}[t]||[];
 let at=AC.currentTime;for(const[f,d,w,v]of T){const o=AC.createOscillator(),g=AC.createGain();o.type=w;o.frequency.value=f;g.gain.setValueAtTime(v,at);g.gain.exponentialRampToValueAtTime(.0001,at+d);o.connect(g);g.connect(AC.destination);o.start(at);o.stop(at+d);at+=d*.8}}catch(e){}}
// ---- entrada ----
const IN={x:0,y:0},K={};let TURBO=false;const jb=$('#joystick-base'),js=$('#joystick-stick');let jid=null;
function jmove(e){const r=jb.getBoundingClientRect();let dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,d=Math.hypot(dx,dy),m=r.width*.42;if(d>m){dx*=m/d;dy*=m/d}js.style.transform=`translate(${dx}px,${dy}px)`;IN.x=dx/m;IN.y=dy/m}
jb.addEventListener('pointerdown',e=>{jid=e.pointerId;jb.setPointerCapture(jid);jmove(e)});jb.addEventListener('pointermove',e=>{if(e.pointerId==jid)jmove(e)});
const jend=e=>{if(e.pointerId==jid){jid=null;IN.x=IN.y=0;js.style.transform=''}};jb.addEventListener('pointerup',jend);jb.addEventListener('pointercancel',jend);
for(const[id,k]of[['a','A'],['b','B'],['c','C']])$('#btn-'+id).addEventListener('pointerdown',e=>{e.preventDefault();act(k)});
const bt=$('#btn-t');bt.addEventListener('pointerdown',e=>{e.preventDefault();TURBO=true;bt.classList.add('hold')});
for(const ev of['pointerup','pointercancel','pointerleave'])bt.addEventListener(ev,()=>{TURBO=false;bt.classList.remove('hold')});
addEventListener('keydown',e=>{if(K[e.code])return;K[e.code]=1;if(e.code=='KeyJ'||e.code=='Space')act('A');if(e.code=='KeyK')act('B');if(e.code=='KeyL')act('C');if(e.code=='KeyU')act('P')});
$('#btn-p').addEventListener('pointerdown',e=>{e.preventDefault();act('P')});const gb=$('#btn-g'),gset=v=>{if(G&&G.hu)G.hu.gd=v;gb.style.filter=v?'brightness(1.6)':''};gb.addEventListener('pointerdown',e=>{e.preventDefault();gset(true)});['pointerup','pointercancel','pointerleave'].forEach(ev=>gb.addEventListener(ev,()=>gset(false)));addEventListener('keydown',e=>{if(e.code=='KeyH')gset(true)});addEventListener('keyup',e=>{if(e.code=='KeyH')gset(false)});$('#btn-q').addEventListener('pointerdown',e=>{e.preventDefault();act('Q')});$('#btn-s').addEventListener('pointerdown',e=>{e.preventDefault();act('S')});addEventListener('keydown',e=>{if(e.code=='KeyI')act('Q');if(e.code=='KeyO')act('S')});setInterval(()=>{try{if(G&&G.P){const p=G.hu,b=$('#btn-p');b.textContent=CH[p.id].pw;b.style.opacity=performance.now()<(p.pwT||0)?.4:1}}catch(e){}},300);addEventListener('keyup',e=>K[e.code]=0);
function humanIn(){const x=(K.KeyD||K.ArrowRight?1:0)-(K.KeyA||K.ArrowLeft?1:0),y=(K.KeyS||K.ArrowDown?1:0)-(K.KeyW||K.ArrowUp?1:0);return[x||IN.x,y||IN.y]}
// ---- partida ----
let G=null;const persp=y=>(y-108)/1042,scl=p=>BASE*persp(p.y);
const SKL=[{spd:.88,steal:.006,block:.012,cross:.6,stat:.82,sb:0,turbo:0,perf:.08},{spd:1,steal:.011,block:.02,cross:1,stat:1,sb:0,turbo:.5,perf:.18},{spd:1.03,steal:.019,block:.04,cross:1.5,stat:1.15,sb:.1,turbo:1,perf:.32}];
const xr=y=>{const m=Math.max(40,390-1.13*(y-955)+10);return[m,LW-m]};
function mkP(t,id,lvl,st,mul,col){const s=statsOf(id,lvl,st,mul);
 return{t,id,col,s,name:CH[id].name,x:0,y:0,z:0,vx:0,vy:0,f:t?-1:1,dir:t?-1:1,st:'idle',tt:0,cd:0,an:0,mv:false,spd:4.5+s.vel*.04,ph:0,ratio:0,stam:100,tired:false,sprint:false,slow:0,ct:0,aiTurbo:false}}
function startMatch(diff,rv){
 const me=save.owned[save.sel],mc=CH[save.sel].jc,rc=rv.col||rivalColor(mc,CH[rv.id].jc);
 const a=mkP(0,save.sel,me.lvl,me.st,1,mc),b=mkP(1,rv.id,rv.lvl,rv.st,SKL[diff].stat,rc);
 G={P:[a,b],hu:a,B:{h:null,fl:null,dk:null,net:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,last:null,pcd:0},s:[0,0],t:120,mode:'intro',mt:170,diff,rv,fx:[],fr:0,poss:0,sd:false,shake:0,rc,mc,cam:-1};
 hudPortrait($('#hpL'),a.id,mc);hudPortrait($('#hpR'),b.id,rc);$('#nL').textContent=a.name;$('#nR').textContent=b.name;
 $('.hp.l').style.setProperty('--cl',mc);$('.hp.r').style.setProperty('--cr',rc);$('#sL').textContent=$('#sR').textContent=0;
 $('#hud').classList.remove('hidden');$('#controls').classList.remove('hidden');musicPlay('match');restart(0)}
const opp=p=>{let b=null,bd=1e9;for(const q of G.P)if(q.t!==p.t){const d=dist(p,q);if(d<bd){bd=d;b=q}}return b};
const SLOTPOS=[['PG','SG'],['SF','SG'],['PF','C']],SLOTN=['BASE','ALERO','PÍVOT'];
function pickHu(){const B=G.B,h=G.hu;if(B.h&&B.h.t===0){if(h!==B.h){h.gd=false;G.hu=B.h}return}
 if(h.st!=='idle'&&h.st!=='cross')return;const tg=B.h||{x:B.x,y:B.y};let best=h,bd=dist(h,tg)-70;
 for(const q of G.P)if(q.t===0&&q!==h&&q.st==='idle'){const d=dist(q,tg);if(d<bd){bd=d;best=q}}if(best!==h){h.gd=false;G.hu=best}}
function switchHu(){if(G.n!==3)return;const B=G.B,tg=B.h||{x:B.x,y:B.y};let best=null,bd=1e9;for(const q of G.P)if(q.t===0&&q!==G.hu&&q.st==='idle'){const d=dist(q,tg);if(d<bd){bd=d;best=q}}if(best){G.hu.gd=false;G.hu=best;sfx('card')}}
function bestOpen(p){let b=null,bs=-1;for(const q of G.P)if(q.t===p.t&&q!==p){let m=1e9;for(const o of G.P)if(o.t!==p.t)m=Math.min(m,dist(o,q));if(m>bs){bs=m;b=q}}return b}
function choosePass(p){const[ix,iy]=p===G.hu?humanIn():[0,0],m=Math.hypot(ix,iy);if(m>.3){let b=null,bs=-9;for(const q of G.P)if(q.t===p.t&&q!==p){const dx=q.x-p.x,dy=q.y-p.y,s=(dx*ix+dy*iy)/((Math.hypot(dx,dy)||1)*m);if(s>bs){bs=s;b=q}}return b}return bestOpen(p)}
function doPass(p,t){const B=G.B;if(G.n!==3||B.h!==p||p.st!=='idle'||p.cd>0)return;t=t||choosePass(p);if(!t)return;B.h=null;B.ps={t:0,T:14+(dist(p,t)/60|0),x0:p.x+p.f*30,y0:p.y,z0:70,tgt:t,from:p};B.x=B.ps.x0;B.y=p.y;B.z=70;p.cd=16;p.f=t.x>=p.x?1:-1;sfx('bounce')}
function ai3(p){const B=G.B,h=hoopOf(p),sk=SKL[G.diff],guy=B.h,SP=[[520,-190],[520,190],[240,0]][p.sl];p.aiTurbo=false;p.gd=false;
 const spot=()=>[h.x-p.dir*SP[0],h.y+SP[1]+Math.sin(G.fr/50+p.sl*2)*40];
 const go=(tx,ty)=>{const dx=tx-p.x,dy=ty-p.y,d=Math.hypot(dx,dy);return d<14?[0,0]:[dx/Math.max(1,d)*Math.min(1,d/90),dy/Math.max(1,d)*Math.min(1,d/90)]};
 if(guy===p){const o=opp(p);if(p.cd===0&&dist(p,o)<250&&rnd()<.02){const m=bestOpen(p);if(m){doPass(p,m);return[0,0]}}return ai1(p,o)}
 if(guy&&guy.t===p.t){const s=spot();return go(s[0],s[1])}
 if(guy){if(G.P[(guy.t?0:3)+guy.sl]===p)return ai1(p,guy);const m=G.P[(p.t?0:3)+p.sl],g=hoopOf(m);
  if(p.cd===0&&(guy.st==='shoot'||guy.st==='dunk')&&dist(p,guy)<260&&rnd()<sk.block)doBlock(p);
  p.gd=dist(p,m)<220;return go(m.x+(g.x-m.x)*.3,m.y+(g.y-m.y)*.3)}
 if(B.ps){const s=spot();return p===B.ps.tgt?[0,0]:go(s[0],s[1])}
 let near=p,bd=dist(p,B);for(const q of G.P)if(q.t===p.t){const d=dist(q,B);if(d<bd-20){near=q;bd=d}}
 if(near===p&&G.mode==='play')return go(B.x,B.y);const s=spot();return go(s[0],s[1])}
function restart3(t){G.poss++;const od=t?-1:1;for(const p of G.P){p.st='idle';p.tt=0;p.z=0;p.vx=p.vy=0;p.cd=20;p.slow=0}
 for(const p of G.P){const k=p.sl,off=p.t===t;p.x=LW/2-od*(170+60*k)+(off?0:od*210);p.y=(off?[1170,1090,1260]:[1235,1150,1310])[k];p.f=off?od:-od}
 const o=G.P[t*3],B=G.B;B.fl=B.dk=B.ps=null;B.net=false;B.rim=null;B.h=o;B.last=null;B.pcd=0;G.hu=t===0?o:(G.hu||G.P[0])}
function startMatch3(){const L=(save.lineup||lineupAuto()).slice(),used=new Set(L.filter(i=>i>=0)),tm=TEAMS[curTeam],P=[];
 const own=k=>{let id=L[k];if(id>=0&&save.owned[id])return{id,lvl:save.owned[id].lvl,st:save.owned[id].st};let pool=CH.filter(c=>c.rar==0&&SLOTPOS[k].includes(c.pos)&&!used.has(c.id));if(!pool.length)pool=CH.filter(c=>!used.has(c.id));const c=pool[rnd()*pool.length|0];used.add(c.id);return{id:c.id,lvl:1,st:0}};
 const mine=[0,1,2].map(own),mc=CH[mine[0].id].jc,rc=rivalColor(mc,tm.col),al=Math.max(1,Math.round(mine.reduce((a,m)=>a+m.lvl,0)/3));
 mine.forEach((m,k)=>{const q=mkP(0,m.id,m.lvl,m.st,1,mc);q.sl=k;P.push(q)});
 tm.ids.forEach((id,k)=>{const q=mkP(1,id,al,0,1,rc);q.sl=k;P.push(q)});
 G={P,n:3,hu:P[0],B:{h:null,fl:null,dk:null,ps:null,net:false,x:0,y:0,z:0,vx:0,vy:0,vz:0,last:null,pcd:0},s:[0,0],t:150,mode:'intro',mt:170,diff:1,rv:tm,fx:[],fr:0,poss:0,sd:false,shake:0,rc,mc,cam:-1};
 hudPortrait($('#hpL'),P[0].id,mc);hudPortrait($('#hpR'),P[3].id,rc);$('#nL').textContent='TU EQUIPO';$('#nR').textContent=tm.name;
 $('.hp.l').style.setProperty('--cl',mc);$('.hp.r').style.setProperty('--cr',rc);$('#sL').textContent=$('#sR').textContent=0;
 $('#hud').classList.remove('hidden');$('#controls').classList.remove('hidden');musicPlay('match');restart(0)}
const rageOn=p=>(p.rage||0)>performance.now(),RCOL={'TITÁN':'#b266ff','CORONA':'#ffd23d','REY 3PT':'#ff6a1a'};
const blkP=(p,o,b)=>rageOn(p)?rnd()<clamp((o.s.def-80)/110,0,.4):(o.pw2||rnd()<b);
function flashFx(c){const f=$('#flash');if(!f)return;f.style.background=`radial-gradient(circle,${c}00 30%,${c}cc 100%)`;f.classList.remove('on');void f.offsetWidth;f.classList.add('on')}
function rageStart(p,txt){const c=RCOL[CH[p.id].pw]||'#ffffff';p.rage=performance.now()+9000;G.shake=26;flashFx(c);msg(txt,90);burst(p.x,p.y-80,c,30,12);pop(p.x,p.y-300,txt,c,40);sfx('perfect');taunt(p,'rage');G.slow=60;cinematic(p);const w=CH[p.id].pw;fxRing(p.x,p.y,c,320);setTimeout(()=>{if(G)fxRing(p.x,p.y,'#fff',460,40)},150);fxBeam(p.x,p.y,c);if(w==='TITÁN')for(let i=0;i<8;i++)fxBolt(p.x+(rnd()-.5)*320,p.y+(rnd()-.5)*40,c);if(w==='CORONA')coinRain(p.x,p.y-60);if(w==='REY 3PT'){burst(p.x,p.y-60,'#ff6a1a',40,14);burst(p.x,p.y-60,'#ffd23d',26,10)}}
function drawAura(g,p,sc){const t=G.fr,w=CH[p.id].pw,col=RCOL[w]||'#ffffff',hh=CH[p.id].h||1,H=210*sc*hh,x=p.x,y=p.y-p.z;g.save();g.globalCompositeOperation='lighter';const r=Math.max(2,H*.62*(1+.08*Math.sin(t*.3))),gr=g.createRadialGradient(x,y-H*.45,5,x,y-H*.45,r);gr.addColorStop(0,col+'99');gr.addColorStop(1,col+'00');g.fillStyle=gr;g.beginPath();g.ellipse(x,y-H*.45,r*.8,r,0,0,7);g.fill();g.restore();
 if(w==='CORONA'){g.save();g.font=Math.round(46*sc*hh)+'px serif';g.textAlign='center';g.fillText('👑',x,y-H*1.04+Math.sin(t*.2)*4*sc);g.restore()}}
const TP={
ankle:['¡Te dejé en el suelo!','¿Dónde estás? ¡Aquí no!','Ata los cordones, campeón','Eso fue un tobillo roto','Te mareé con un solo toque','Sigue buscándome…','¡Cuidado con las rodillas!','Me debes unas zapatillas','Qué lento eres, hermano','¡Ni lo viste venir!','Eso fue arte callejero','¡Pídele ayuda a tu mamá!'],
score:['¡Esta cancha es mía!','Fácil, otra más','¡Anótalo en tu libreta!','Sin sudar','¡Qué calidad!','Aquí mando yo','Dos puntos al bolsillo','Ni mirando fallo','¡A casa con esa!','Te lo dije, soy el mejor','¡Siguiente!','Siéntate y mira'],
three:['¡Desde el barrio!','¡Más lejos, más bonito!','Red, solo red','¡Lluvia de triples!','Dime que no es de 3…','¡Ni tocó el aro!','Mi muñeca no falla','¡Cuenta tres, mi amigo!','¡Desde el parking!','Fría como el hielo'],
dunk:['¡Cuidado con el aro!','¡Te pasé por encima!','Esto es altura, no suerte','¡Rompe-aros!','¡Aquí no se pasa!','¡Mira desde abajo!','Vuelo directo','¡Con furia!','Sin visa para entrar','El aro tiembla'],
block:['¡Aquí no pasa nada!','¡Vete de aquí!','¡Prohibido anotar!','Fuera de mi casa','¡No en mi cancha!','¡Rechazado!','Devuélvelo al remitente','¡Puerta cerrada!','¡Nada de eso!','Hoy no, amigo'],
steal:['¡Mía, gracias!','¡Manos de seda!','Se te cayó, tranquilo','¡Qué descuido!','Lo tomé prestado','¡Con permiso!','¡Robo en la calle!','Te lo devuelvo… nunca','¡Pillado!','Ojo con la pelota'],
rage:['¡MODO FURIA!','¡Ahora sí van a sufrir!','¡Nadie me para!','¡Siente el poder!','¡Esto se acaba YA!','¡Desatado!']};
const TL={'TITÁN':['¡Ni un muro me para!','¡Tiemblen, pequeños!','¡El aro es mío!','¡Soy el Coloso!'],'CORONA':['¡Inclínense ante el Rey!','¡La corona no se discute!','¡El trono me espera!','¡Rey en la casa!'],'REY 3PT':['¡Desde donde quiera!','¡Rey del Triple!','¡Red, sin tocar!','¡Fuego en las manos!']};
function taunt(p,ev){if(!G||(G.tc||0)>G.fr)return;const t=$('#taunt');if(!t)return;let a=TP[ev];const w=CH[p.id].pw;if(TL[w]&&rnd()<.45)a=TL[w];G.tc=G.fr+150;
 t.className=p.t===0?'L':'R';t.innerHTML=`<img src="${figImg(p.id,p.col)}"><div><b>${CH[p.id].name}</b><span>${a[rnd()*a.length|0]}</span></div>`;void t.offsetWidth;t.classList.add('on');clearTimeout(taunt.o);taunt.o=setTimeout(()=>t.classList.remove('on'),2300)}
function shotClock(){const B=G.B;if(G.sc==null)G.sc=16;
 if(B.h){if((G.loose||0)>20||B.h.t!==G.scT){G.sc=16;G.scT=B.h.t}G.loose=0;
  if(B.h.st==='idle'||B.h.st==='cross'){G.sc-=1/60;if(G.sc<=0){const h=B.h;sfx('buzz');msg('¡TIEMPO DE POSESIÓN!',80);pop(h.x,h.y-260,'RELOJ','#f66',44);G.sc=16;G.scT=-1;inbound(1-h.t)}}}else G.loose=(G.loose||0)+1}
function inbound(t){G.poss++;G.sc=16;G.scT=-1;const dT=t?-1:1,hd=HOOP[t?1:0],bx=hd.x-dT*170,YS=[1090,1010,1250];
 for(const p of G.P){p.st='idle';p.tt=0;p.z=0;p.vx=p.vy=0;p.cd=20;p.slow=0}
 G.P.forEach(p=>{const k=G.n===3?p.sl:0;if(p.t===t){p.x=k?bx+dT*340:bx;p.y=YS[k];p.f=dT}else{p.x=LW/2+dT*(230+90*k);p.y=YS[k];p.f=-dT}});
 const o=G.n===3?G.P[t*3]:G.P[t],B=G.B;B.fl=B.dk=B.ps=null;B.net=false;B.rim=null;B.h=o;B.last=null;B.pcd=0;if(G.n===3)G.hu=t===0?o:(G.hu||G.P[0])}
function startTip(){G.mode='tip';G.mt=140;const B=G.B;B.h=null;B.fl=B.dk=B.ps=null;B.net=false;B.rim=null;B.vx=B.vy=B.vz=0;msg('¡SALTO INICIAL!',70);
 G.tipP=G.n===3?[G.P[2],G.P[5]]:[G.P[0],G.P[1]];
 for(const p of G.P){p.st='idle';p.tt=0;p.z=0;p.vx=p.vy=0;p.mv=false;p.gd=false}
 G.P.forEach(p=>{if(G.tipP.includes(p)){p.x=LW/2+(p.t?60:-60);p.y=1150;p.f=p.t?-1:1}else{const k=G.n===3?p.sl:0;p.x=LW/2+(p.t?1:-1)*(260+70*k);p.y=[1060,1250,1320][k%3];p.f=p.t?-1:1}})}
function tipTick(){const B=G.B,m=G.mt--;B.x=LW/2;B.y=1150;B.z=m>90?(140-m)*6:Math.max(70,300-(90-m)*3);
 if(m===100)for(const q of G.tipP){q.st='block';q.tt=0}
 if(m===55){const sc=q=>(q.s.mat*.5+q.s.def*.5)*(CH[q.id].h||1)+rnd()*12,w=sc(G.tipP[0])>=sc(G.tipP[1])?G.tipP[0]:G.tipP[1];G.tipW=w;pop(w.x,w.y-260,'¡GANA EL SALTO!','#ffe45c',44);msg(CH[w.id].name+' gana el salto',60);sfx('swish')}
 if(m<=0){const w=G.tipW||G.tipP[0];G.mode='play';restart(w.t);msg('¡YA!',40);return}
 for(const q of G.tipP)if(q.st==='block')stepP(q)}
const fxRing=(x,y,c,r1=260,T=34)=>G.fx.push({k:'ring',x,y,t:0,T,c,r1});
const fxBolt=(x,y,c)=>{const pts=[[0,0]];let px=0,py=0;for(let i=0;i<7;i++){px+=(rnd()-.5)*46;py-=60+rnd()*40;pts.push([px,py])}G.fx.push({k:'bolt',x,y,t:0,T:14,c,pts})};
const fxBeam=(x,y,c)=>G.fx.push({k:'beam',x,y,t:0,T:46,c});
const coinRain=(x,y)=>{for(let i=0;i<26;i++)G.fx.push({k:'p',x:x+(rnd()-.5)*320,y:y-rnd()*160,vx:(rnd()-.5)*3,vy:rnd()*2,t:0,T:50+rnd()*20,c:i%3?'#ffd23d':'#fff3a0',sz:12+rnd()*8})};
function cinematic(p){const e=$('#cine');if(!e)return;e.style.setProperty('--c',RCOL[CH[p.id].pw]||'#ffffff');e.innerHTML=`<img src="${figImg(p.id,CH[p.id].jc)}"><div><small>${CH[p.id].title||''}</small><b>${CH[p.id].pw}</b></div>`;e.classList.remove('on');void e.offsetWidth;e.classList.add('on')}
function legendFx(p,kind,pts){if(!rageOn(p))return;const w=CH[p.id].pw,c=RCOL[w],h=hoopOf(p);
 if(w==='TITÁN'&&kind=='dunk'){fxRing(h.x,h.y,c,430);fxRing(h.x,h.y,'#fff',300);for(let i=0;i<7;i++)fxBolt(h.x+(rnd()-.5)*380,h.y,c)}
 else if(w==='CORONA'){fxBeam(h.x,h.y,c);coinRain(h.x,h.y-300);fxRing(h.x,h.y,c,300)}
 else if(w==='REY 3PT'){burst(h.x,792,'#ff6a1a',44,14);burst(h.x,792,'#ffd23d',26,10);fxRing(h.x,h.y,c,320);if(pts==3)coinRain(h.x,h.y-300)}}
const MUS={tr:'menu',step:0,next:0,timer:null,gain:null,nb:null};
function musCtx(){AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(!MUS.gain){MUS.gain=AC.createGain();MUS.gain.gain.value=1.25;const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=9000;const cp=AC.createDynamicsCompressor();MUS.gain.connect(lp);lp.connect(cp);cp.connect(AC.destination)}return AC}
const mN=m=>440*Math.pow(2,(m-69)/12);
function mTone(t,m,d,ty,v){const o=AC.createOscillator(),g=AC.createGain();o.type=ty;o.frequency.value=mN(m);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(MUS.gain);o.start(t);o.stop(t+d+.05)}
function mNoise(t,d,f,v,type){if(!MUS.nb){const b=AC.createBuffer(1,AC.sampleRate*.5,AC.sampleRate),a=b.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;MUS.nb=b}const s=AC.createBufferSource(),fl=AC.createBiquadFilter(),g=AC.createGain();s.buffer=MUS.nb;fl.type=type;fl.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(fl);fl.connect(g);g.connect(MUS.gain);s.start(t);s.stop(t+d+.02)}
function mKick(t,v){const o=AC.createOscillator(),g=AC.createGain();o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(42,t+.14);g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0001,t+.28);o.connect(g);g.connect(MUS.gain);o.start(t);o.stop(t+.3)}
const CHORDS=[[57,60,64,67],[53,57,60,64],[50,53,57,60],[52,56,59,62]],ROOTS=[33,29,26,28],PENT=[69,72,74,76,79,81];
function musStep(s,t){const m=MUS.tr==='match',bar=(s>>4)&3,st=s&15,ch=CHORDS[bar],hype=!!(G&&G.P&&G.P.some(rageOn));
 if((m?[0,4,8,10,12]:[0,7,10]).includes(st))mKick(t,.9);
 if(st===4||st===12){mNoise(t,.16,1800,.5,'bandpass');mTone(t,52,.1,'triangle',.25)}
 if(st%2===0||m)mNoise(t,.04,8000,st%4===2?.22:.12,'highpass');
 if([0,3,6,10,12,14].includes(st)||(m&&st%2===0))mTone(t,ROOTS[bar]+(st===14?12:0),.22,'sawtooth',.2);
 if(st===0||st===6||(m&&(st===8||st===14)))for(const n of ch)mTone(t,n,m?.22:.5,'triangle',.07);
 if((m||hype)&&st%2===1)mTone(t,ch[(st>>1)%4]+12,.12,'square',.05);
 if(st%4===2&&Math.random()<(m?.7:.5))mTone(t,PENT[(Math.random()*PENT.length)|0]+(hype?12:0),.28,'sine',.12);
 if(hype&&st%4===0)mTone(t,ch[0]+24,.25,'sawtooth',.06)}
function musicPlay(tr){if(!save.snd){musicStop();return}try{musCtx();if(AC.state==='suspended')AC.resume()}catch(e){return}if(tr)MUS.tr=tr;if(MUS.timer)return;MUS.step=0;MUS.next=AC.currentTime+.08;
 MUS.timer=setInterval(()=>{if(!AC)return;const dt=60/(MUS.tr==='match'?108:92)/4;while(MUS.next<AC.currentTime+.18){musStep(MUS.step,MUS.next);MUS.next+=dt;MUS.step++}},30)}
function musicStop(){clearInterval(MUS.timer);MUS.timer=null}
document.addEventListener('pointerdown',()=>{if(save.snd)musicPlay(MUS.tr);else if(AC&&AC.state==='suspended')AC.resume()});
function restart(t){if(G.n===3)return restart3(t);const o=G.P[t],d=G.P[1-t];G.poss++;
 for(const p of G.P){p.st='idle';p.tt=0;p.z=0;p.vx=p.vy=0;p.cd=20;p.slow=0}
 o.x=LW/2-o.dir*170;o.y=1170;d.x=o.x+o.dir*210;d.y=1235;o.f=o.dir;d.f=-o.dir;
 const B=G.B;B.fl=B.dk=null;B.net=false;B.rim=null;B.h=o;B.last=null;B.pcd=0}
function msg(t,f=60){const m=$('#msg');m.textContent=t;m.classList.add('on');clearTimeout(msg.o);msg.o=setTimeout(()=>m.classList.remove('on'),f*16)}
function pop(x,y,txt,c='#ffe45c',s=64){G.fx.push({k:'t',x,y,t:0,T:70,txt,c,s})}
function burst(x,y,c,n=14,sp=9){for(let i=0;i<n;i++){const a=rnd()*6.28,v=sp*(.3+rnd());G.fx.push({k:'p',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-3,t:0,T:30+rnd()*20,c})}}
const dist=(a,b)=>Math.hypot(a.x-b.x,(a.y-b.y)*1.6);
const hoopOf=p=>HOOP[p.dir>0?1:0];
const dunkable=p=>{const h=hoopOf(p);return Math.abs(p.x-h.x)<(rageOn(p)?380:280)&&Math.abs(p.y-h.y)<170};
const driveable=p=>{const h=hoopOf(p);return Math.abs(p.x-h.x)<(rageOn(p)?520:430)&&Math.abs(p.y-h.y)<210};
// frameOf -> [frame, ballAnchored, ballPos]
function frameOf(p){const hb=G.B.h===p,a=p.an,t=p.tt;
 switch(p.st){
  case'shoot':return t<8?['LU0',hb]:t<18?['LU1',hb]:t<32?['LU2',hb]:t<44?['LU1',0]:['DF0',0];
  case'dunk':{if(t<p.dk0)return[SPR[(a/3|0)%8],hb];const u=t-p.dk0;return u<8?['LU0',hb]:u<22?['LU1',hb]:u<38?['LU2',hb]:u<52?['LU1',0]:['DF0',0]}
  case'steal':return[t<16?'DF1':'DF0',0];
  case'shove':return['DF1',0];
  case'block':return['LU1',0];
  case'cross':{const q=XS[p.ck];let a2=t;for(const[n,d]of q){if(a2<d)return[n,hb];a2-=d}return[q[q.length-1][0],hb]}
  case'fall':return t<12?['E1',0]:t<28?['E2',0]:t<80?['E3',0]:t<112?['E4',0]:t<122?['E3',0]:t<134?['DZ0',0]:['DZ1',0];
  case'win':return[CEL[(t/22|0)%4],0];case'lose':return[(t/24|0)%2?'TR1':'TR0',0]}
 if(p.mv){const c=p.cyc||0,g=p.gait||0;if(g===2)return[SPR[(c*8|0)%8],hb];if(g===1)return[(hb?RA:SPR)[(c*8|0)%8],hb];return[WALKALL[(c*WALKALL.length|0)%WALKALL.length],hb]}
 if(hb){const o=opp(p);if(dist(p,o)<230)return[HOLD[(a/14|0)%4],1];return[IDB[(a/8|0)%4],1]}
 if(G.B.h&&G.B.h!==p)return[DSH[(a/14|0)%4],0];
 return[NIDLE[(a/16|0)%4],0]}
function ballScreen(p){if(p.st==='shoot'||p.st==='dunk'){const r=rigBall(p),k=scl(p)*1.1*(CH[p.id].h||1);return[p.x+p.f*r[0]*k,p.y-p.z+r[1]*k]}const[fn,bf,bp]=frameOf(p),f=FR[fn],b=bp||f.ball,sc=scl(p)*(f.k||1);if(!b)return[p.x,p.y-p.z-120*sc];return[p.x+p.f*b[0]*sc,p.y-p.z+b[1]*sc]}
// ---- acciones ----
function act(k){if(!G||G.mode!=='play')return;const p=G.hu,B=G.B;if(k==='S')return switchHu();if(k==='Q')return doPass(p);if(k==='P')return usePower(p);
 if(p.st==='shoot'&&k==='A'&&B.h===p&&p.tt>=8&&p.tt<=38){release(p,p.tt);return}
 if(p.st==='dunk'&&k==='A'&&B.h===p&&!p.dkind&&p.lt==null&&p.tt-p.dk0>=0&&p.tt-p.dk0<20){p.lt=p.tt-p.dk0+10;return}
 if(p.st!=='idle')return;
 if(k==='A'){if(B.h===p)doShoot(p);else if(B.h)doSteal(p)}
 else if(k==='B'){if(B.h===p)doDunk(p);else doBlock(p)}
 else{if(B.h===p)doCross(p,...humanIn());else doShove(p)}}
function usePower(p){const now=performance.now();if(p.st!=='idle')return;if(now<(p.pwT||0)){pop(p.x,p.y-260,'RECARGANDO','#aaa',30);return}
 const w=CH[p.id].pw,o=opp(p),has=G.B.h===p,dd=dist(p,o),tx=(s,c='#ffe45c')=>pop(p.x,p.y-270,s,c,38),cd=ms=>p.pwT=now+ms,fall=()=>{o.st='fall';o.tt=0;o.vx=-p.dir*6};
 switch(w){
 case'TITÁN':{const B=G.B,h=hoopOf(p);if(!has&&!B.dk&&(B.fl||B.z>30)&&Math.abs(p.x-h.x)<520){cd(12000);rageStart(p,'¡PUTBACK TITÁN!');const f=B.fl,rm=B.rim;B.fl=null;B.rim=null;B.h=p;doDunk(p);if(p.st!=='dunk'){B.h=null;B.fl=f;B.rim=rm}else{p.dkind=5;B.x=p.x;B.y=p.y}}else{cd(16000);rageStart(p,'¡MODO TITÁN!')}break}
 case'CORONA':cd(16000);rageStart(p,'¡CORONA DEL REY!');break;
 case'REY 3PT':cd(16000);rageStart(p,'¡3 POINT KING!');if(has){doShoot(p);p.pw=1}break;
 case'TURBO':{const s0=p.spd;p.spd=s0*1.4;p.stam=100;cd(9000);setTimeout(()=>p.spd=s0,2500);tx('¡TURBO!','#7fff9f');break}
 case'CRUCE':if(!has)return;cd(10000);if(dd<320){fall();taunt(p,'ankle');tx('¡TOBILLOS!','#ffb347')}else tx('¡CRUCE!','#ffb347');doCross(p,p.dir,0);break;
 case'STEPBACK':case'RAYO':if(!has)return;cd(9000);doShoot(p);p.pw=1;tx(w==='STEPBACK'?'¡STEPBACK!':'¡TIRO RAYO!');sfx('perfect');break;
 case'FUEGO':cd(14000);p.fire=3;tx('¡EN LLAMAS! x3','#ff8a3d');break;
 case'ESCUDO':cd(12000);p.sh=now+5000;tx('¡ESCUDO! (sin marca)','#7ff');break;
 case'TOMAHAWK':case'CAÑON':if(!has||!driveable(p)){pop(p.x,p.y-260,'CERCA DEL ARO CON BALÓN','#aaa',24);return}cd(10000);doDunk(p);p.dkind=w==='TOMAHAWK'?3:4;if(w==='CAÑON'&&dd<320)fall();tx('¡'+w+'!','#ff7a7a');break;
 case'MURO':if(has&&driveable(p)){cd(10000);doDunk(p);p.dkind=5;tx('¡360 SMASH!','#ff7a7a')}else if(!has){cd(9000);p.pw2=1;setTimeout(()=>p.pw2=0,1400);doBlock(p);tx('¡MURO!','#7ff')}break;
 case'TERREMOTO':cd(14000);if(dd<380){if(!has)stolen(p,o);else fall()}tx('¡TERREMOTO!','#ffb347');G.shake=14;break}}
function usePowerOld(p){const now=performance.now();if(p.st!=='idle')return;if(now<(p.pwT||0)){pop(p.x,p.y-260,'RECARGANDO','#aaa',30);return}
 const ps=CH[p.id].pos,has=G.B.h===p,tx=(s,c='#ffe45c')=>pop(p.x,p.y-270,s,c,38);
 if(ps==='SG'||ps==='SF'){if(!has)return;p.pwT=now+9000;doShoot(p);p.pw=1;tx(ps==='SG'?'¡STEPBACK!':'¡TIRO RAYO!');sfx('perfect')}
 else if(ps==='PF'){if(!has||!driveable(p)){pop(p.x,p.y-260,'CERCA DEL ARO CON BALÓN','#aaa',24);return}p.pwT=now+10000;doDunk(p);p.dkind=3;tx('¡TOMAHAWK!','#ff7a7a')}
 else if(ps==='C'){if(has&&driveable(p)){p.pwT=now+10000;doDunk(p);p.dkind=5;tx('¡360 SMASH!','#ff7a7a')}else if(!has){p.pwT=now+9000;p.pw2=1;setTimeout(()=>p.pw2=0,1400);doBlock(p);tx('¡MURO!','#7ff')}}
 else{const s0=p.spd;p.spd=s0*1.4;p.stam=100;p.pwT=now+9000;setTimeout(()=>p.spd=s0,2500);tx('¡TURBO!','#7fff9f')}}
function doShoot(p){if(G.B.h!==p||p.st!=='idle')return;p.f=p.dir;p.tt=0;p.st='shoot';sfx('bounce')}
function doDunk(p){if(G.B.h!==p||p.st!=='idle'||!driveable(p)){if(p===G.hu&&G.B.h===p)pop(p.x,p.y-260,'MUY LEJOS','#aaa',34);return}
 const h=hoopOf(p);p.f=p.dir;p.tt=0;p.st='dunk';p.x0=p.x;p.y0=p.y;p.tx=h.x-p.dir*(dunkable(p)?92:120);p.ty=clamp(h.y+(p.y-h.y)*.3,1010,1330);
 p.dk0=clamp(Math.hypot(p.tx-p.x,p.ty-p.y)/12,14,40)|0;p.dkind=dunkable(p)?(rageOn(p)?3+(rnd()*3|0):1+(rnd()*5|0)):0;p.lt=null;sfx('bounce')}
function doSteal(p){if(p.st!=='idle'||p.cd>0)return;p.st='steal';p.tt=0;p.cd=34}
function doBlock(p){if(p.st!=='idle'||p.cd>0)return;p.st='block';p.tt=0;p.cd=55}
function doShove(p){if(p.st!=='idle'||p.cd>0)return;p.st='shove';p.tt=0;p.cd=70}
function doCross(p,ix,iy){if(G.B.h!==p||p.st!=='idle'||p.cd>0)return;let m=Math.hypot(ix,iy);if(m<.2){ix=p.dir;iy=0;m=1}p.cx=ix/m;p.cy=iy/m;p.ck=rnd()*3|0;p.vk=CH[p.id].pw==='REY 3PT'?[1,2,4,0][rnd()*4|0]:rnd()*5|0;p.cl=XL[p.ck];p.st='cross';p.tt=0;p.cd=75;if(p.cx)p.f=p.cx>0?1:-1;burst(p.x,p.y,'#ddd',8,6)}
function stolen(th,v){const B=G.B;taunt(th,'steal');B.h=th;th.cd=26;v.st='fall';v.tt=0;v.vx=(v.x>=th.x?1:-1)*7;v.vy=0;burst(v.x,v.y-90,'#fff',10,8);pop(th.x,th.y-250,'¡ROBO!','#7ff');sfx('steal');setTimeout(()=>sfx('fall'),120)}
const ARCP=[[976,400],[987,600],[1020,733],[1047,827],[1073,887],[1093,916],[1160,893],[1200,853],[1243,747],[1273,600],[1291,400],[1303,173]];
function arcX(y){if(y<=ARCP[0][0])return 400;for(let i=1;i<ARCP.length;i++)if(y<=ARCP[i][0]){const a=ARCP[i-1],b=ARCP[i];return a[1]+(b[1]-a[1])*(y-a[0])/(b[0]-a[0])}return 100}
const isThree=(p,h)=>(h.x<LW/2?p.x:LW-p.x)>arcX(p.y)+8;
function gcl(p){const o=opp(p);if(!o||G.B.h!==p||o.st!=='idle'||(p.sh||0)>performance.now())return 0;return Math.max(0,1-dist(o,p)/250)*(o.gd?1:.35)*(o.ai?[.5,.8,1][G.diff]:1)}
function zoneW(st,d,dd,three,gc=0){let g=(1.3+(st-35)/16)*(1.35-.6*clamp((d-250)/600,0,1))*(1+(three?(st-62)/90:0));g*=(1-.45*Math.max(0,1-dd/230))*(1-.85*gc);g=clamp(g,gc>.05?.1:.8,7);const y=(g*.9+1.6)*(1-.6*gc);return{g,y,ye:y*.5}}
function zoneOf(W,te){const e=te-24;if(Math.abs(e)<=W.g)return'g';if(e<0)return-e-W.g<=W.y?'y':'o';return e-W.g<=W.ye?'y':'o'}
function layZone(p,u){const h=hoopOf(p),d=Math.hypot(Math.abs(p.x-h.x),(p.y-h.y)*1.6),o=opp(p),st=(p.s.mat+p.s.tir)/2,W=zoneW(st,d,dist(o,p),false,gcl(p));
 const te=p.lt!=null?p.lt:p.ai?24+(rnd()+rnd()-1)*[5,3.5,2.2][G.diff]*(1.15-st/170):u+10,zn=zoneOf(W,te);p.mk={te,zn,W,age:0};
 if(zn==='g'&&p.t===0){pop(p.x,p.y-300,'¡VERDE!','#6f6',40);sfx('perfect')}return zn}
function drawMeter(g,p,sc){const mk=p.mk,gc=gcl(p);if(p===G.hu&&p.gd&&G.B.h&&G.B.h.t!==p.t){const t=G.B.h;g.save();g.setLineDash([14,10]);g.strokeStyle='#ff4d4dcc';g.lineWidth=4*sc;g.beginPath();g.moveTo(p.x,p.y-70*sc);g.lineTo(t.x,t.y-70*sc);g.stroke();g.setLineDash([]);g.beginPath();g.ellipse(t.x,t.y,Math.max(1,52*sc),Math.max(1,26*sc),0,0,7);g.stroke();g.beginPath();g.moveTo(t.x-70*sc,t.y);g.lineTo(t.x+70*sc,t.y);g.moveTo(t.x,t.y-36*sc);g.lineTo(t.x,t.y+36*sc);g.stroke();g.restore()}if(gc>.25&&p.t===0){g.save();g.font=Math.round(24*sc)+'px "Press Start 2P",monospace';g.textAlign='center';g.fillStyle='#ff5252';g.strokeStyle='#000';g.lineWidth=4*sc;g.strokeText('🛡 MARCADO',p.x,p.y-p.z-290*sc);g.fillText('🛡 MARCADO',p.x,p.y-p.z-290*sc);g.restore()}let te=null,W=null,zn=null,fin=false;
 if(false&&p===G.hu&&G.B.h===p&&(p.st==='shoot'&&p.tt>=2||p.st==='dunk'&&!p.dkind&&p.tt-p.dk0>=0&&p.lt==null&&p.tt-p.dk0<20)){const h=hoopOf(p),d=Math.hypot(Math.abs(p.x-h.x),(p.y-h.y)*1.6),dk=p.st==='dunk';
  W=zoneW(dk?(p.s.mat+p.s.tir)/2:p.s.tir,d,dist(opp(p),p),!dk&&isThree(p,h),gcl(p));te=dk?p.tt-p.dk0+10:p.tt}
 else if(false&&mk&&mk.age<50){W=mk.W;te=mk.te;zn=mk.zn;fin=true;mk.age++}
 if(!W)return;
 const[X,Y]=ballScreen(p),bx=X-p.f*58*sc,H=190*sc,top=Y-H*.62,bot=top+H,t0=8,t1=24+W.g+W.ye+2,Yt=t=>bot-(clamp(t,t0,t1)-t0)/(t1-t0)*H,w=22*sc;
 const zs=[[t0,24-W.g-W.y,'#ff7a1a'],[24-W.g-W.y,24-W.g,'#ffd23d'],[24-W.g,24+W.g,'#3df05a'],[24+W.g,24+W.g+W.ye,'#ffd23d'],[24+W.g+W.ye,t1,'#ff7a1a']];
 g.save();g.globalAlpha=fin?Math.min(1,(50-mk.age)/20):1;g.fillStyle='#000d';g.fillRect(bx-w/2-4*sc,top-4*sc,w+8*sc,H+8*sc);
 for(const[a,b,c]of zs){g.fillStyle=c;g.fillRect(bx-w/2,Yt(b),w,Yt(a)-Yt(b))}
 const live=!fin&&zoneOf(W,te)==='g',mc=fin?{g:'#3df05a',y:'#ffd23d',o:'#ff7a1a'}[zn]:live?'#7fff9f':'#fff';g.strokeStyle=live||(fin&&zn==='g')?'#7fff9f':'#fff';g.lineWidth=3*sc;g.strokeRect(bx-w/2-4*sc,top-4*sc,w+8*sc,H+8*sc);
 g.fillStyle='#000';g.fillRect(bx-w*1.3-2*sc,Yt(te)-6*sc,w*2.6+4*sc,12*sc);g.fillStyle=mc;g.fillRect(bx-w*1.3,Yt(te)-4*sc,w*2.6,8*sc);
 if(fin&&zn==='g'){g.strokeStyle='#3df05a';g.shadowColor='#3df05a';g.shadowBlur=12;g.lineWidth=7*sc;g.beginPath();g.moveTo(bx,top);g.lineTo(bx,bot);g.stroke()}
 g.restore()}
function release(p,t=29){const B=G.B,o=opp(p),h=hoopOf(p),dx=Math.abs(p.x-h.x),d=Math.hypot(dx,(p.y-h.y)*1.6),three=isThree(p,h),dd=dist(o,p);
 if(o.st==='block'&&o.z>25&&dd<180&&blkP(p,o,clamp(.42+(o.s.def-p.s.tir)/220,.12,.8))){return swat(p,o)}
 const own=p.dir>0?p.x<LW/2:p.x>LW/2;let cont=clamp(1-dd/260,0,1);if(o.gd)cont=clamp(cont*1.5,0,1);if((p.sh||0)>performance.now())cont=0;
 let pr=.9-.00056*d+(p.s.tir-50)/260;if(three)pr+=(p.s.tir-62)/400;pr*=1-.85*cont;if(p.pw){pr=.97;p.pw=0}else if(p.fire>0){pr=.97;p.fire--}
 if(rageOn(p)){const nm=CH[p.id].pw;if(nm==='REY 3PT')pr=three||d>600?.99:Math.min(.97,pr+.2);else if(nm==='CORONA')pr=Math.min(.97,pr+.25);else pr=Math.min(.97,pr+.1)}
 pr=own?0:clamp(pr,.03,.97);const ok=rnd()<pr;
 if(p.t===0&&!own){if(cont>.55)pop(p.x,p.y-300,'MUY MARCADO','#ff6a6a',34);else if(cont<.12)pop(p.x,p.y-300,'¡DESMARCADO!','#6f6',34)}else if(p.t===0&&own)pop(p.x,p.y-300,'MUY LEJOS','#aaa',34);
 const[X,Y]=ballScreen(p);B.h=null;B.last=p;const T=clamp(34+d*.028,36,68),g=.55,z0=p.y-Y;
 B.fl={t:0,T,ok,p,three,x0:X,y0:p.y,z0,tx:h.x+(ok?0:(rnd()-.5)*90),ty:h.y+(ok?0:(rnd()-.5)*70),g,vz:(RIM_Z-z0+.5*g*T*T)/T};B.x=X;B.y=p.y;B.z=z0;sfx('bounce')}
function swat(p,o){const B=G.B;taunt(o,'block');const[X,Y]=ballScreen(p);B.h=null;B.fl=B.dk=null;B.last=p;B.x=X;B.y=p.y;B.z=Math.max(10,p.y-Y);B.vx=-p.dir*(7+rnd()*5);B.vy=(rnd()-.5)*7;B.vz=5;
 G.shake=8;pop(o.x,o.y-260,'¡TAPÓN!','#ff8a3d');sfx('block')}
function scored(p,pts,kind){const B=G.B,h=hoopOf(p);G.s[p.t]+=pts;$('#sL').textContent=G.s[0];$('#sR').textContent=G.s[1];
 B.fl=B.dk=null;B.h=null;B.net=true;B.x=h.x;B.y=h.y;B.z=RIM_Z;B.vx=B.vy=0;B.vz=-1;B.last=p;
 G.mode='score';G.mt=150;G.who=p.t;taunt(p,kind=='dunk'?'dunk':pts==3?'three':'score');flashFx('#ffd23d');if(kind=='dunk'&&rageOn(p)){for(const q of G.P)if(q.t!==p.t&&dist(q,p)<420){q.st='fall';q.tt=0;q.vx=q.x>=p.x?7:-7;q.vy=0}burst(p.x,p.y-40,'#fff',30,13);G.shake=28}legendFx(p,kind,pts);const txt=kind=='dunk'?'¡MATE!':pts==3?'¡TRIPLE!':'¡CANASTA!';msg(txt,90);if(kind=='dunk')G.shake=16;
 pop(h.x+(p.dir>0?-120:120),600,'+'+pts,'#ffe45c',90);burst(h.x,792,'#ffd23a',22,11);sfx(kind=='dunk'?'dunk':'swish');
 for(const q of G.P)if(q.st==='idle'){q.st=q.t===p.t?'win':'lose';q.tt=0}}
function rimMiss(p,hard){const B=G.B,h=hoopOf(p);B.fl=B.dk=null;B.x=h.x;B.y=h.y;B.z=RIM_Z;B.vx=-p.dir*(2+rnd()*5);B.vy=(rnd()-.5)*6;B.vz=hard?8:5+rnd()*4;B.pcd=22;sfx('block');if(rnd()<(hard?.45:.7))B.rim={t:0,T:(14+rnd()*38)|0,vx:B.vx,vy:B.vy,vz:B.vz,h};if(hard)pop(h.x-p.dir*100,650,'¡FALLÓ!','#f66',50)}
// ---- movimiento ----
function move(p,ix,iy,k=1){const B=G.B,m=Math.hypot(ix,iy),sp=p.spd*k*(B.h===p?.93:1)*(p.gd?.8:1)*(rageOn(p)&&CH[p.id].pw==='CORONA'?1.25:1)*(p.ai?SKL[G.diff].spd:1);
 const tx=m>.08?ix/Math.max(1,m)*sp:0,ty=m>.08?iy/Math.max(1,m)*sp*.58:0;p.vx+=(tx-p.vx)*.3;p.vy+=(ty-p.vy)*.3;
 p.x+=p.vx;p.y+=p.vy;p.mv=Math.hypot(p.vx,p.vy)>1.3;
 if(Math.abs(p.vx)>1.3)p.f=p.vx>0?1:-1;else{const o=opp(p);p.f=B.h===p?p.dir:(o.x>=p.x?1:-1)}}
function clampP(p){p.y=clamp(p.y,1010,1330);const[a,b]=xr(p.y);p.x=clamp(p.x,a,b)}
const lerp=(a,b,t)=>a+(b-a)*t;
function stepP(p){p.an++;if(p.cd>0)p.cd--;const B=G.B,o=opp(p),play=G.mode==='play';
 let ix=0,iy=0;
 if(p.st==='idle'){let want=false;if(play){if(p===G.hu){[ix,iy]=humanIn();want=TURBO||K.ShiftLeft||K.ShiftRight}else{[ix,iy]=ai(p,o);want=p.aiTurbo}}
  const mv=Math.hypot(ix,iy)>.25;let k=1;
  if(want&&mv&&p.stam>0&&!p.tired){k=1.2;p.stam-=1.7;if(p.stam<=0){p.stam=0;p.tired=true}}else{p.stam=Math.min(100,p.stam+(mv?.14:.55));if(p.tired&&p.stam>=30)p.tired=false}
  p.sprint=k>1;if(p.slow>0){k*=.5;p.slow--}
  move(p,ix,iy,k);clampP(p);if(G.mode==='score')p.mv=false;
  if(p.mv){p.ratio=Math.min(1.5,Math.hypot(p.vx,p.vy*1.7)/p.spd);p.ph+=.13+.2*p.ratio;const gp=p.gait||0;p.gait=p.sprint?2:(gp===1?(p.ratio>.5?1:0):(p.ratio>.66?1:0));const sc=scl(p),D=[105,165,205][p.gait]*sc,c0=p.cyc||0;p.cyc=(c0+Math.hypot(p.vx,p.vy)/D)%1;if(p.gait>0&&((c0*2)|0)!==((p.cyc*2)|0)&&G.mode==='play')G.fx.push({k:'p',x:p.x-p.f*16,y:p.y-3,vx:-p.f*1.4,vy:-.8,t:0,T:12,c:'#fff7'})}else p.ratio=0}
 else{p.tt++;const t=p.tt;p.sprint=false;
  if(p.st==='shoot'){p.vx*=.8;p.vy*=.8;p.z=t>4&&t<44?90*Math.sin(Math.PI*(t-4)/40):0;if(t===29&&B.h===p)release(p,29);if(t>=48){p.st='idle';p.z=0;p.cd=8}}
  else if(p.st==='dunk'){const T0=p.dk0,e=t<T0?t/T0:1;p.x=lerp(p.x0,p.tx,e);p.y=lerp(p.y0,p.ty,e);p.mv=t<T0;
   const u=t-T0;if(u>0)p.x=p.tx+p.dir*(p.dkind?46:30)*Math.min(1,u/22);p.z=u>0&&u<50?(p.dkind?178:150)*Math.pow(Math.sin(Math.PI*u/50),.75):0;if(u===1)burst(p.x,p.y,'#fff8',10,6);
   if(u===20&&B.h===p){const[X,Y]=ballScreen(p);B.h=null;B.dk={t:0,T:7,x0:X,y0:p.y,z0:p.y-Y,p};p.lz=null;B.x=X;B.y=p.y;B.z=p.y-Y}
   if(u>=64){p.st='idle';p.z=0;p.cd=10;p.mv=false}}
  else if(p.st==='steal'){if(t<10){p.vx=p.f*5;p.x+=p.vx;clampP(p)}else{p.vx*=.7}
   if(t===7){const h=B.h;if(h&&h.t!==p.t&&Math.abs(h.x-p.x)<165&&Math.abs(h.y-p.y)<95&&h.st!=='shoot'&&h.st!=='dunk'){
     if(h.st==='cross'&&h.tt<20){if(rageOn(h)||rnd()<clamp(.55+(h.s.reg-p.s.def)/200,.25,.9)){p.st='fall';p.tt=0;p.vx=-p.f*6;pop(h.x,h.y-270,'¡TOBILLOS!','#ffb347',44);taunt(h,'ankle');sfx('fall')}}
     else if(rnd()<clamp(.24+(p.s.def-h.s.reg)/200+(p.ai?SKL[G.diff].sb:0),.07,.75))stolen(p,h)}}
   if(t>=22&&p.st==='steal')p.st='idle'}
  else if(p.st==='shove'){if(t===6){const h=B.h;if(h&&h.t!==p.t&&Math.abs(h.x-p.x)<150&&Math.abs(h.y-p.y)<95&&h.st==='idle'&&rnd()<.55+(p.s.def-h.s.reg)/300){h.slow=80;h.vx+=p.f*9;pop(h.x,h.y-260,'¡EMPUJÓN!','#ffb347',40);sfx('block')}}if(t>=16)p.st='idle'}
  else if(p.st==='block'){p.vx*=.8;p.z=t<38?120*Math.sin(Math.PI*t/38):0;if(t>=40){p.st='idle';p.z=0}}
  else if(p.st==='cross'){const f=Math.max(0,1-t/p.cl),sp=p.spd;p.vx=p.cx*sp*1.9*f;p.vy=p.cy*sp*1.1*f;p.x+=p.vx;p.y+=p.vy;clampP(p);p.mv=false;if(Math.abs(p.vx)>1)p.f=p.vx>0?1:-1;if(t>=p.cl){p.st='idle'}}
  else if(p.st==='fall'){p.x+=p.vx;p.vx*=.9;clampP(p);if(t>146){p.st='idle';p.cd=16}}
  else if(p.st==='win'){p.z=(CEL[(t/22|0)%4]=='CE0'||CEL[(t/22|0)%4]=='CE1')&&t%22<11?Math.abs(Math.sin(t/3.5))*26:0}
  else if(p.st==='lose'){p.vx=p.vy=0}}
 if(G.mode==='play'&&p.st==='idle'&&dist(p,o)<62&&o.st==='idle'){const s=(p.x<o.x?-1:1)*1.6;p.x+=s;clampP(p)}}
// ---- IA ----
function ai(p,o){const r=G.n===3?ai3(p):ai1(p,o);p.aiTurbo=p.aiTurbo&&rnd()<.3;return r}
function ai1(p,o){const B=G.B,sk=SKL[G.diff],h=hoopOf(p);let tx=p.x,ty=p.y;p.aiTurbo=false;p.gd=!!B.h&&B.h===o&&p.st==='idle'&&dist(p,o)<300;if(G.diff&&p.st==='idle'&&rnd()<.0025*G.diff&&Math.abs(p.x-h.x)<760)usePower(p);
 if(B.h===p){const d=Math.hypot(h.x-p.x,(h.y-p.y)*1.6),near=dist(o,p);
  if(!p.plan||p.plan.id!==G.poss)p.plan={id:G.poss,t:0,style:(p.s.mat>p.s.tir+6||rnd()<.35)?'drive':'jump',w:rnd()*6.28,sh:(p.s.tir>60?640:540)+rnd()*130};
  const pl=p.plan;pl.t++;
  if(pl.style==='drive'){tx=h.x-p.dir*70;ty=h.y+Math.sin(pl.t/45+pl.w)*100}else{tx=h.x-p.dir*pl.sh;ty=h.y+Math.sin(pl.t/40+pl.w)*150}
  if(near<200)ty+=(p.y>=o.y?1:-1)*140;
  p.aiTurbo=sk.turbo>0&&Math.abs(tx-p.x)>300&&rnd()<sk.turbo+.4;
  if(p.cd===0){
   if(near<230&&rnd()<.011*sk.cross)doCross(p,tx-p.x,ty-p.y);
   else if(pl.style==='drive'&&driveable(p)&&Math.abs(h.x-p.x)<520&&rnd()<.06)doDunk(p);
   else if(pl.style==='jump'&&Math.abs(h.x-p.x)<pl.sh+50&&rnd()<.05)doShoot(p);
   else if(d<420&&rnd()<.03)doShoot(p);
   else if(pl.t>420)doShoot(p)}
 }else if(B.h){const hh=B.h,g=hoopOf(hh);tx=hh.x+(g.x-hh.x)*.2;ty=hh.y+(g.y-hh.y)*.12;const near=dist(p,hh);
  p.aiTurbo=sk.turbo>0&&near>260&&rnd()<sk.turbo;
  if(p.cd===0){if(near<150&&rnd()<sk.steal)doSteal(p);else if(near<140&&rnd()<sk.steal*.35)doShove(p);else if((hh.st==='shoot'||hh.st==='dunk')&&near<260&&rnd()<sk.block)doBlock(p)}
 }else{if(G.mode==='play'){tx=B.x;ty=B.y;p.aiTurbo=sk.turbo>0&&Math.hypot(tx-p.x,ty-p.y)>250}}
 const dx=tx-p.x,dy=ty-p.y,d=Math.hypot(dx,dy);return d<14?[0,0]:[dx/Math.max(1,d)*Math.min(1,d/90),dy/Math.max(1,d)*Math.min(1,d/90)]}
// ---- balón ----
function stepBall(){const B=G.B;if(B.pcd>0)B.pcd--;
 if(B.h)return;
 if(B.ps){const s=B.ps;s.t++;const k=s.t/s.T,t=s.tgt;B.x=lerp(s.x0,t.x,k);B.y=lerp(s.y0,t.y,k);B.z=lerp(s.z0,80,k)+Math.sin(Math.PI*k)*34;
  if(s.t>=s.T){B.ps=null;let q=null,bd=75;for(const o of G.P)if(o.t!==s.from.t&&o.st!=='fall'){const d=dist(o,t);if(d<bd){bd=d;q=o}}
   if(q&&rnd()<.45){B.h=q;q.cd=22;pop(q.x,q.y-250,'¡PASE ROBADO!','#7ff')}else{B.h=t;t.cd=Math.max(t.cd,10)}}return}
 if(B.dk){const d=B.dk;d.t++;const k=d.t/d.T,h=hoopOf(d.p);B.x=lerp(d.x0,h.x,k);B.y=lerp(d.y0,h.y,k);B.z=lerp(d.z0,RIM_Z+10,k);
  if(d.t>=d.T){const p=d.p,o=opp(p);const base=clamp((.72+(p.s.mat-50)/200+(p.dkind?.18:0))*(1-.6*clamp(1-dist(o,p)/230,0,1)*(o.gd?1.4:1)),.1,.97),ok=rnd()<base;
   if(o.st==='block'&&o.z>20&&dist(o,p)<230&&blkP(p,o,clamp(.38+(o.s.def-p.s.mat)/220,.15,.75))){swat(p,o);return}
   if(ok)scored(p,2,'dunk');else rimMiss(p,true)}return}
 if(B.fl){const f=B.fl;f.t++;const k=f.t/f.T;B.x=lerp(f.x0,f.tx,k);B.y=lerp(f.y0,f.ty,k);B.z=f.z0+f.vz*f.t-.5*f.g*f.t*f.t;
  if(f.t>=f.T){if(f.ok){if(rnd()<.28){B.fl=null;B.rim={t:0,T:(12+rnd()*16)|0,h:hoopOf(f.p),sc:f.p,pts:f.three?3:2}}else scored(f.p,f.three?3:2,'shot')}else rimMiss(f.p,false)}return}
 if(B.rim){const r=B.rim;r.t++;const a=r.t*.45;B.x=r.h.x+Math.cos(a)*20;B.y=r.h.y+Math.sin(a)*8;B.z=RIM_Z+Math.abs(Math.sin(a*1.3))*10;if(r.t===1)sfx('block');if(r.t>=r.T){B.rim=null;if(r.sc){scored(r.sc,r.pts,'shot');return}B.vx=r.vx;B.vy=r.vy;B.vz=r.vz;B.pcd=10}return}
 if(B.net){B.vz-=.5;B.z+=B.vz;if(B.z<=0){B.z=0;B.vz=-B.vz*.4;if(Math.abs(B.vz)<2)B.vz=0}return}
 B.x+=B.vx;B.y+=B.vy;B.z+=B.vz;B.vz-=.55;
 if(B.z<=0){B.z=0;B.vz=Math.abs(B.vz)>3?-B.vz*.55:0;B.vx*=.93;B.vy*=.93;if(B.vz>2.5)sfx('bounce')}
 B.y=clamp(B.y,1000,1340);const[a,b]=xr(B.y);B.x=clamp(B.x,a-30,b+30);
 if(G.mode==='play'&&B.pcd<=0){const cs=[];for(const p of G.P){if(p.st==='fall'||p.st==='dunk'||p.st==='shoot')continue;const d=Math.hypot(p.x-B.x,(p.y-B.y)*1.6);if(d<110&&B.z<190)cs.push([p,d])}
  if(cs.length){let best=null,bs=-1e9;for(const[p,d]of cs){const s=(p.s.mat*.5+p.s.def*.5)*(CH[p.id].h||1)-d*.25+rnd()*22;if(s>bs){bs=s;best=p}}
   if(B.z>35){for(const[p]of cs)if(p.st==='idle'){p.st='block';p.tt=6}pop(best.x,best.y-260,'¡REBOTE!','#7ff',40);sfx('bounce')}
   B.h=best;best.cd=Math.max(best.cd,22)}}}
// ---- ciclo ----
function tick(){if(!G)return;G.fr++;if(G.slow>0){G.slow--;if(G.fr%3)return}const B=G.B;
 if(G.shake>0)G.shake--;
 if(G.mode==='intro'){G.mt--;const n=Math.ceil(G.mt/50);if(G.mt%50===0&&n>0&&n<4)msg(String(n),40);if(G.mt<=0)startTip()}
 else if(G.mode==='score'){if(--G.mt<=0){if(G.sd||G.t<=0)return endMatch();inbound(1-G.who);G.mode='play'}}
 else if(G.mode==='tip')tipTick();
 else if(G.mode==='play'){shotClock();G.t-=1/60;if(G.t<=0){G.t=0;const busy=B.fl||B.dk||G.P.some(p=>p.st==='shoot'||p.st==='dunk');if(!busy){if(G.s[0]!==G.s[1]){sfx('buzz');return endMatch()}if(!G.sd){G.sd=true;msg('¡MUERTE SÚBITA!',90)}}}}
 for(const p of G.P)p.ai=p!==G.hu;if(G.n===3)pickHu();if(G.mode!=='tip'){for(const p of G.P)stepP(p);stepBall();if(B.fl||B.dk||B.ps){const rg=B.last&&rageOn(B.last);G.fx.push({k:'p',x:B.x,y:B.y-B.z,vx:0,vy:0,t:0,T:rg?18:10,c:rg?RCOL[CH[B.last.id].pw]:'#ffb347',sz:rg?24:12,g:0})};
  for(const p of G.P){if(p.gd&&B.h&&B.h.t!==p.t&&p.st==='idle')p.f=B.h.x>=p.x?1:-1;if(rageOn(p)&&G.fr%2==0){const c=RCOL[CH[p.id].pw]||'#ffffff';if(G.fr%14===0){const w=CH[p.id].pw;if(w==='TITÁN')fxBolt(p.x+(rnd()-.5)*140,p.y,c);else if(w==='CORONA'&&G.fr%28===0)fxBeam(p.x,p.y,c);else if(w==='REY 3PT')burst(p.x,p.y-90,'#ffd23d',3,5)}G.fx.push({k:'p',x:p.x+(rnd()-.5)*50,y:p.y-p.z-rnd()*150,vx:(rnd()-.5)*2,vy:-2-rnd()*3,t:0,T:22,c,sz:8+rnd()*8,g:-.05});if(p.mv)G.fx.push({k:'p',x:p.x,y:p.y,vx:0,vy:0,t:0,T:46,c:c+'aa',sz:22,g:0})}}}
 for(let i=G.fx.length-1;i>=0;i--){const e=G.fx[i];e.t++;if(e.k==='p'){e.x+=e.vx;e.y+=e.vy;e.vy+=(e.g==null?.5:e.g)}if(e.t>e.T)G.fx.splice(i,1)}
 if(G.mode==='end')return;
 if(G.fr%6===0){const p=G.hu,a=B.h===p,ba=$('#btn-a'),bb=$('#btn-b'),bc=$('#btn-c');
  $('#btn-q').style.display=$('#btn-s').style.display=G.n===3?'':'none';ba.textContent=a?(p.st==='shoot'?'¡SUELTA!':'TIRAR'):'ROBAR';bb.textContent=a?'MATE':'TAPÓN';bc.textContent=a?'REGATE':'EMPUJAR';
  bb.classList.toggle('dim',a&&!driveable(p));$('#stam i').style.width=p.stam+'%';$('#stam').classList.toggle('low',p.tired);
  $('#sclk').textContent=Math.ceil(G.sc==null?16:G.sc);$('#sclk').classList.toggle('w',G.sc<=5);const t=Math.ceil(G.t);$('#clock').textContent=G.sd?'¡YA!':Math.floor(t/60)+':'+String(t%60).padStart(2,'0')}}
function endMatch(){G.mode='end';musicPlay('menu');const w=G.s[0]>G.s[1],c=(w?150:40)+G.s[0]*(w?10:8)+(w?G.diff*50:0);save.coins+=c;save.played++;if(w)save.wins++;store();
 const g=G;setTimeout(()=>{$('#eT').textContent=w?'🏆 ¡VICTORIA!':'DERROTA';$('#eS').textContent=g.s[0]+' - '+g.s[1];$('#eC').innerHTML=`+${c} 🪙<br>Partidos ${save.played} · Victorias ${save.wins}`;$('#controls').classList.add('hidden');$('#hud').classList.add('hidden');show('#end')},900)}
// ---- cámara / dibujo ----
function sboard(t,s0,s1){const g=ctx;g.save();g.font='26px "Press Start 2P",monospace';g.textAlign='center';g.textBaseline='middle';
 for(const m of[0,1]){const X=x=>m?LW-x:x;
  g.fillStyle='#0d0810';g.fillRect(m?LW-212:96,268,116,60);g.fillRect(m?LW-112:52,354,60,56);g.fillRect(m?LW-176:146,372,30,44);g.fillRect(m?LW-268:210,378,58,50);
  g.fillStyle='#5f5';g.fillText(t,X(153),298);g.fillStyle='#ff4a3a';g.font='32px "Press Start 2P",monospace';g.fillText(String(s0).padStart(2,'0'),X(82),392);g.fillText(String(s1).padStart(2,'0'),X(240),400);
  g.fillStyle='#ffb52e';g.font='28px "Press Start 2P",monospace';g.fillText('1',X(161),396)}g.restore()}
function draw(){const w=innerWidth,h=innerHeight,port=h>w*1.05,VW=port?950:1900;ctx.setTransform(dpr,0,0,dpr,0,0);
 const bg=ctx.createLinearGradient(0,0,0,h);bg.addColorStop(0,'#05060f');bg.addColorStop(1,'#10162e');ctx.fillStyle=bg;ctx.fillRect(0,0,w,h);
 S=w/VW;offY=port?Math.max(.47*h-1150*S,150-792*S):Math.max(.5*h-1150*S,62-792*S);
 let cam=0;if(G){const a=G.hu,b=opp(a),B=G.B;let fx=(a.x+b.x)/2;if(!B.h&&G.mode!=='intro')fx=fx*.6+B.x*.4;const tg=clamp(fx-VW/2,0,LW-VW);G.cam=G.cam<0?tg:G.cam+(tg-G.cam)*.1;cam=G.cam}else cam=(LW-VW)/2;
 let sx=0,sy=0;if(G&&G.shake>0){sx=(rnd()-.5)*G.shake;sy=(rnd()-.5)*G.shake}
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.save();ctx.translate(sx,offY+sy);ctx.scale(S,S);ctx.translate(-cam,0);
 ctx.drawImage(IM.stadium,0,0,LW,LH);
 if(!G){ctx.restore();return}
 const t=Math.ceil(G.t);sboard(G.sd?'0:00':Math.floor(t/60)+':'+String(t%60).padStart(2,'0'),G.s[0],G.s[1]);
 const B=G.B;
 for(const p of G.P){const sc=scl(p);ctx.fillStyle=`rgba(0,0,0,${.32-Math.min(.2,p.z/700)})`;ctx.beginPath();ctx.ellipse(p.x,p.y,(p.st==='fall'?70:42)*sc/.85*.9,13*sc/.85,0,0,7);ctx.fill()}
 if(!B.h){const k=persp(B.y)*BASE;ctx.fillStyle=`rgba(0,0,0,${.35-Math.min(.2,B.z/900)})`;ctx.beginPath();ctx.ellipse(B.x,B.y,Math.max(1,24*k/.85),Math.max(1,8*k/.85),0,0,7);ctx.fill()}
 const L=[...G.P.map(p=>({y:p.y,p})),...(!B.h?[{y:B.y+(B.z>200?-30:0),b:1}]:[])].sort((a,b)=>a.y-b.y);
 for(const o of L){if(o.b){const k=persp(B.y)*BASE,r=26*k;ballImg(ctx,B.x,B.y-B.z-r,r);continue}
  const p=o.p,[fn,bl,bp]=frameOf(p),sc=scl(p);let dr=null;if(B.h===p&&bl&&(p.st==='idle'||p.st==='cross')){const mvg=p.st==='idle'&&p.mv;let u;if(mvg){u=((((p.cyc||0)-CYL[p.gait||0]-.04+.5)%1)+1)%1}else{u=(p.an%24)/24}dr=[Math.abs(Math.cos(Math.PI*u)),mvg?6+14*Math.min(1.2,p.ratio):0];if(p.t===0&&(p.dbp||0)<.5&&u>=.5)sfx('bounce');p.dbp=u}else p.dbp=0;RIG_ST.includes(p.st)?drawRigFig(ctx,p.x,p.y-p.z,sc,p.f,p.col,p.id,rigOf(p,dr)):drawFig(ctx,fn,p.x,p.y-p.z,sc,p.f,p.col,p.id,bl&&B.h===p,bp,(p.st==='idle'||p.st==='cross'&&0)?gaitOf(p.ph,p.mv?p.ratio:0,p.an):null,dr,p.st==='idle'&&p.mv?[p.cyc||0,p.gait||0]:null);drawMeter(ctx,p,sc);if(rageOn(p))drawAura(ctx,p,sc);
  if(p.st==='fall'&&p.tt>24&&p.tt<110){ctx.font=`${40*sc/.85}px sans-serif`;ctx.textAlign='center';for(let i=0;i<3;i++){const a=G.fr/8+i*2.1;ctx.fillText('⭐',p.x+Math.cos(a)*55*sc,p.y-95*sc+Math.sin(a)*10-p.z)}}
  if(p.sprint&&G.fr%3==0)G.fx.push({k:'p',x:p.x-p.f*30,y:p.y-8,vx:-p.f*2,vy:-1,t:0,T:14,c:'#fff8'})}
 const hp=G.hu;if(G.mode!=='end'){const sc=scl(hp),x=hp.x,y=hp.y-hp.z-310*sc+Math.sin(G.fr/6)*6;ctx.fillStyle='#ffe45c';ctx.strokeStyle='#000';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x-18,y-22);ctx.lineTo(x+18,y-22);ctx.lineTo(x,y+4);ctx.closePath();ctx.fill();ctx.stroke()
  }
 for(const e of G.fx){if(e.k==='t'){const a=1-e.t/e.T;ctx.globalAlpha=Math.max(0,a);ctx.font=`${e.s}px "Press Start 2P",monospace`;ctx.textAlign='center';ctx.lineWidth=8;ctx.strokeStyle='#000';ctx.strokeText(e.txt,e.x,e.y-e.t*2);ctx.fillStyle=e.c;ctx.fillText(e.txt,e.x,e.y-e.t*2);ctx.globalAlpha=1}
  else if(e.k==='ring'){const k=e.t/e.T,r=e.r1*k;ctx.save();ctx.globalAlpha=1-k;ctx.strokeStyle=e.c;ctx.lineWidth=10*(1-k)+2;ctx.beginPath();ctx.ellipse(e.x,e.y,Math.max(1,r),Math.max(1,r*.38),0,0,7);ctx.stroke();ctx.restore()}
  else if(e.k==='bolt'){ctx.save();ctx.globalAlpha=1-e.t/e.T;ctx.strokeStyle='#fff';ctx.shadowColor=e.c;ctx.shadowBlur=18;ctx.lineWidth=5;ctx.beginPath();e.pts.forEach(([a,b],i)=>i?ctx.lineTo(e.x+a,e.y+b):ctx.moveTo(e.x,e.y));ctx.stroke();ctx.restore()}
  else if(e.k==='beam'){const k=e.t/e.T,w=60*(1-k*.5),gr=ctx.createLinearGradient(0,e.y-900,0,e.y);gr.addColorStop(0,e.c+'00');gr.addColorStop(1,e.c+'cc');ctx.save();ctx.globalAlpha=1-k;ctx.globalCompositeOperation='lighter';ctx.fillStyle=gr;ctx.fillRect(e.x-w/2,e.y-900,w,900);ctx.restore()}
  else{ctx.globalAlpha=Math.max(0,1-e.t/e.T);ctx.fillStyle=e.c;{const z=e.sz||10;ctx.fillRect(e.x-z/2,e.y-z/2,z,z)};ctx.globalAlpha=1}}
 ctx.restore()}
let last=0,acc=0;
function loop(ts){requestAnimationFrame(loop);const dt=Math.min(100,ts-last);last=ts;acc+=dt;while(acc>=16.667){tick();acc-=16.667}draw()}
