// ===== Menús, equipo, gacha =====
const show=id=>{$$('.screen').forEach(s=>s.classList.add('hidden'));if(id){const e=$(id);e.classList.remove('hidden');mountPreviews(e)}};
const myCard=()=>cardHTML(save.sel,save.owned[save.sel]);
function fillMenu(){$('#mPl').textContent=save.played;$('#mWi').textContent=save.wins;$('#mRo').textContent=Object.keys(save.owned).length+'/'+CH.length;
 $('#mlegs').innerHTML=[57,56,58].map((i,k)=>`<div class="lg" style="--c:${RCOL[CH[i].pw]};animation-delay:${k*.5}s"><img src="${figImg(i,CH[i].jc)}"><b>${CH[i].name}</b><small>${CH[i].title}</small></div>`).join('')}
function menuFx(){const cv=$('#mcv');if(!cv||menuFx.on)return;menuFx.on=true;const g=cv.getContext('2d'),P=[],cr=[];
 for(let i=0;i<70;i++)P.push({x:Math.random(),y:Math.random(),s:.4+Math.random()*1.4,v:.0004+Math.random()*.0012,c:['#ffd23d','#ff7a1a','#b266ff','#6fdcff'][i%4],p:Math.random()*6});
 for(let i=0;i<36;i++)cr.push({x:i/35,h:.55+Math.random()*.4,p:Math.random()*6,c:['#10142e','#171c3c','#0d1128'][i%3]});
 let t=0;(function L(){if($('#menu').classList.contains('hidden')){menuFx.on=false;return}requestAnimationFrame(L);t++;
  const W=cv.clientWidth|0,H=cv.clientHeight|0;if(cv.width!==W)cv.width=W;if(cv.height!==H)cv.height=H;
  const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#0a0b24');bg.addColorStop(.55,'#2a1050');bg.addColorStop(1,'#43154f');g.fillStyle=bg;g.fillRect(0,0,W,H);
  g.globalCompositeOperation='lighter';for(let i=0;i<4;i++){const a=Math.sin(t*.008+i*1.7)*.5,x=W*(.12+.25*i),gr=g.createLinearGradient(x,0,x+a*H,H);gr.addColorStop(0,['#ffd23d66','#b266ff66','#6fdcff66','#ff7a1a66'][i]);gr.addColorStop(1,'#0000');g.fillStyle=gr;g.beginPath();g.moveTo(x-12,0);g.lineTo(x+12,0);g.lineTo(x+a*H+W*.1,H);g.lineTo(x+a*H-W*.1,H);g.fill()}
  g.globalCompositeOperation='source-over';
  for(const c of cr){const x=c.x*W,bob=Math.sin(t*.05+c.p)*H*.008,hh=H*.14*c.h;g.fillStyle=c.c;g.beginPath();g.arc(x,H*.7-hh+bob,H*.035,0,7);g.fill();g.fillRect(x-H*.045,H*.7-hh+H*.03+bob,H*.09,hh)}
  const fl=g.createLinearGradient(0,H*.7,0,H);fl.addColorStop(0,'#4d2412');fl.addColorStop(1,'#b8631f');g.fillStyle=fl;g.fillRect(0,H*.7,W,H*.3);g.strokeStyle='#ffffff22';g.lineWidth=2;
  for(let i=-8;i<=8;i++){g.beginPath();g.moveTo(W/2+i*W*.02,H*.7);g.lineTo(W/2+i*W*.16,H);g.stroke()}for(let k=1;k<6;k++){const y=H*.7+H*.3*Math.pow(k/6,1.6);g.beginPath();g.moveTo(0,y);g.lineTo(W,y);g.stroke()}
  g.globalCompositeOperation='lighter';for(const p of P){p.y-=p.v;p.x+=Math.sin(t*.02+p.p)*.0006;if(p.y<-.05){p.y=1.05;p.x=Math.random()}g.fillStyle=p.c;g.globalAlpha=.55;g.beginPath();g.arc(p.x*W,p.y*H,p.s*H*.004+1,0,7);g.fill()}g.globalAlpha=1;g.globalCompositeOperation='source-over'})()}
function renderMenu(){store();fillMenu();show('#menu');menuFx();musicPlay('menu')}
$('#b-play').onclick=()=>{curDiff=1;curMode=1;beginVs()};
$('#b-gacha').onclick=()=>{gReset();show('#gacha');store()};
$('#b-team').onclick=()=>{backTo='menu';openTeam()};
$('#b-change').onclick=()=>{backTo='pick';openTeam()};
$('#b-how').onclick=()=>show('#how');
$('#b-snd').onclick=()=>{save.snd=save.snd?0:1;$('#b-snd').textContent=save.snd?'🔊':'🔇';store();save.snd?musicPlay(MUS.tr):musicStop()};
$$('[data-back]').forEach(b=>b.onclick=()=>show('#menu'));
$('#t-back').onclick=()=>{if(backTo==='pick'){$('#b-play').onclick()}else renderMenu()};
$('#g-back').onclick=()=>renderMenu();
// ---- equipo ----
let backTo='menu',tSel=0;let curMode=1,lSlot=0,curTeam=0;
function lineupAuto(){const used=new Set(),L=[];SLOTPOS.forEach(ps=>{const c=CH.filter(x=>save.owned[x.id]&&ps.includes(x.pos)&&!used.has(x.id)).sort((a,b)=>b.rar*100+save.owned[b.id].lvl-a.rar*100-save.owned[a.id].lvl)[0];if(c){used.add(c.id);L.push(c.id)}else L.push(-1)});return L}
function renderLineup(){const L=save.lineup;$('#lslots').innerHTML=L.map((id,k)=>`<div class="ls${lSlot==k?' on':''}" data-k="${k}"><small>${SLOTN[k]}</small>${id>=0?portrait(id):'<div class="inv">🎲</div>'}<b>${id>=0?CH[id].name:'INVITADO'}</b><small>${id>=0?CH[id].pos+' · '+CH[id].pw+' · Nv'+save.owned[id].lvl:SLOTPOS[k].join('/')+' · gratis'}</small></div>`).join('');
 $$('#lslots .ls').forEach(e=>e.onclick=()=>{lSlot=+e.dataset.k;renderLineup()});
 const ok=CH.filter(c=>save.owned[c.id]&&SLOTPOS[lSlot].includes(c.pos)).sort((a,b)=>b.rar-a.rar||a.id-b.id);
 $('#lhint').textContent=`Posición ${SLOTN[lSlot]}: elige un ${SLOTPOS[lSlot].join(' o ')} de tus jugadores (si no tienes, entra un invitado)`;
 $('#lgrid').innerHTML=ok.map(c=>`<div class="slot${L[lSlot]==c.id?' sel':''}" style="--rc:${RAR[c.rar].c}" data-id="${c.id}">${portrait(c.id)}<span class="lvb">Nv${save.owned[c.id].lvl}</span></div>`).join('')+`<div class="slot inv2" data-id="-1">🎲</div>`;
 $$('#lgrid .slot').forEach(e=>e.onclick=()=>{const id=+e.dataset.id;if(id>=0)for(let i=0;i<3;i++)if(L[i]==id)L[i]=-1;L[lSlot]=id;store();renderLineup()});mountPreviews($('#lslots'))}
$('#b-3v3').onclick=()=>{if(!save.lineup||save.lineup.length!==3)save.lineup=lineupAuto();lSlot=0;renderLineup();show('#lineup')};
$('#l-auto').onclick=()=>{save.lineup=lineupAuto();renderLineup()};
$('#l-go').onclick=()=>{renderTeams();show('#teams')};
$('#tm-back').onclick=()=>{renderLineup();show('#lineup')};
function renderTeams(){$('#tmgrid').innerHTML=TEAMS.map((t,i)=>`<div class="tm" data-i="${i}" style="--tc:${t.col}"><b>${t.name}</b><div class="tmf">${t.ids.map(id=>'<span class="tmp">'+portrait(id,1,t.col)+'</span>').join('')}</div><small>${t.ids.map(id=>CH[id].pos).join(' · ')} · OVR ${t.ovr}</small></div>`).join('');
 $$('#tmgrid .tm').forEach(e=>e.onclick=()=>{curTeam=+e.dataset.i;curMode=3;show(null);startMatch3()})}

function openTeam(){tSel=save.sel;renderTeam();show('#team')}
function renderTeam(){
 const owned=Object.keys(save.owned).length;$('#tCount').textContent=`${owned}/${CH.length}`;
 const list=CH.filter(c=>save.owned[c.id]).sort((a,b)=>b.rar-a.rar||a.id-b.id);if(!save.owned[tSel])tSel=save.sel;
 $('#grid').innerHTML=list.map(c=>{const o=save.owned[c.id];return`<div class="slot${tSel==c.id?' sel':''}${save.sel==c.id?' cur':''}" style="--rc:${RAR[c.rar].c}" data-id="${c.id}">${portrait(c.id)}<span class="lvb">Nv${o.lvl}</span></div>`}).join('');
 $$('#grid .slot').forEach(e=>e.onclick=()=>{tSel=+e.dataset.id;renderTeam()});
 const c=CH[tSel],o=save.owned[tSel];let h='';
 if(o){h=cardHTML(tSel,o);const cost=upCost(o.lvl),max=o.lvl>=MAXLV;
  h+=`<div class="dbtns"><button class="btn main" id="d-sel" ${save.sel==tSel?'disabled':''}>${save.sel==tSel?'✓ ELEGIDO':'ELEGIR'}</button><button class="btn" id="d-up" ${max||save.coins<cost?'disabled':''}>${max?'NIVEL MÁX':`MEJORAR Nv${o.lvl}→${o.lvl+1} (${cost}🪙)`}</button></div><div style="font-size:7px;color:#9ad;text-align:center;line-height:1.7">Las copias repetidas del gacha te dan ★ (+2.5 a todo)</div>`}
 else h=`<div class="pcard" style="--rc:${RAR[c.rar].c}"><div class="nm">???</div><div class="rr">★ ${RAR[c.rar].k} · ${c.pos} · ${c.pw} · ${c.title||ARN[c.arch]}</div><div class="lv" style="line-height:1.8">No lo tienes todavía.<br>¡Consíguelo en el Gacha!</div></div>`;
 $('#detail').innerHTML=h;mountPreviews($('#detail'));
 const ds=$('#d-sel');if(ds)ds.onclick=()=>{save.sel=tSel;store();renderTeam()};
 const du=$('#d-up');if(du)du.onclick=()=>{const o=save.owned[tSel],cost=upCost(o.lvl);if(o.lvl<MAXLV&&save.coins>=cost){save.coins-=cost;o.lvl++;store();sfx('card');renderTeam()}}}
// ---- gacha ----
let gres=[],gi=0,gstate='idle';
function gReset(){gres=[];gi=0;gstate='idle';$('#gcard').classList.add('hidden');$('#gsum').classList.add('hidden');$('#gtip').textContent='Elige un sobre y toca la carta para revelarla';$('#gtip').classList.remove('hidden');$('#g-next').classList.add('hidden');$('#gpk').classList.remove('hidden')}
function gOpen(n){const pk=PACKS[n],cost=pk.cost;if(save.coins<cost){$('#gtip').textContent='No tienes monedas suficientes 😢 ¡Juega partidos para ganar más!';return}
 save.coins-=cost;gres=[];for(let i=0;i<pk.cnt;i++){const c=rollGacha(i==pk.cnt-1?pk.min:0,pk.b);gres.push({c,r:grantChar(c)})}store();gi=0;$('#gsum').classList.add('hidden');$('#gpk').classList.add('hidden');gShow()}
function gShow(){const{c,r}=gres[gi],R=RAR[c.rar],card=$('#gcard');
 card.classList.remove('flip','shake','hidden');card.style.setProperty('--rc',R.c);void card.offsetWidth;
 const o=save.owned[c.id];
 $('#gfront').style.setProperty('--rc',R.c);$('#gfront').parentElement.style.setProperty('--rc',R.c);
 const s=statsOf(c.id,o.lvl,o.st);
 $('#gfront').innerHTML=`<canvas width="300" height="300" data-id="${c.id}" data-col="${c.jc}"></canvas><div class="nm">${c.name}</div><div class="rr">★ ${R.k} · ${c.pos} · ${c.pw} · ${c.title||ARN[c.arch]}</div><div style="font-size:7px;color:#cde">OVR ${ovrOf(s)}</div>${r.isNew?'<div class="new">¡NUEVO!</div>':r.star?'<div class="new" style="color:#ffe45c">¡COPIA! +★</div>':`<div class="new" style="color:#ffb347">Copia máx → +${r.coins}🪙</div>`}`;
 mountPreviews($('#gfront'));card.classList.add('shake');gstate='back';$('#g-next').classList.add('hidden');
 $('#gtip').textContent=gres.length>1?`Carta ${gi+1}/${gres.length} · ¡Tócala!`:'¡Toca la carta!'}
$('#gcard').onclick=()=>{if(gstate!=='back')return;gstate='front';const c=gres[gi].c;$('#gcard').classList.remove('shake');$('#gcard').classList.add('flip');
 if(c.rar>=2){const f=$('#flash');f.style.background=RAR[c.rar].c;f.classList.remove('on');void f.offsetWidth;f.classList.add('on')}sfx(c.rar==3?'legend':'card');
 setTimeout(()=>{const last=gi>=gres.length-1;const nb=$('#g-next');nb.classList.remove('hidden');nb.textContent=last?(gres.length>1?'RESUMEN ▶':'OTRA VEZ ▶'):'SIGUIENTE ▶';$('#gtip').textContent=''},700)};
$('#g-next').onclick=()=>{if(gi<gres.length-1){gi++;gShow();return}
 if(gres.length>1){$('#gcard').classList.add('hidden');$('#gsum').innerHTML=gres.map(({c})=>`<div class="slot" style="--rc:${RAR[c.rar].c}">${portrait(c.id)}</div>`).join('');$('#gsum').classList.remove('hidden');$('#g-next').classList.add('hidden');$('#gpk').classList.remove('hidden');$('#gtip').textContent='¡Contenido del sobre!';gres=[]}
 else gReset()};
$('#gpk').innerHTML=PACKS.map((p,i)=>`<button class="btn pk pk${i}" data-i="${i}"><b>${p.e} ${p.n}</b><small>${p.cnt} carta${p.cnt>1?'s':''}${p.min?' · mín. '+RAR[p.min].k:''}</small><span>${p.cost}🪙</span></button>`).join('');$$('#gpk .pk').forEach(b=>b.onclick=()=>gOpen(+b.dataset.i));
// ---- partida ----
let curDiff=1,curRival=null;
$$('[data-d]').forEach(b=>b.onclick=()=>{curDiff=+b.dataset.d;beginVs()});
function beginVs(){curRival=pickRival(curDiff);const me=save.owned[save.sel],mc=CH[save.sel].jc,rc=rivalColor(mc,CH[curRival.id].jc);
 $('#vL').outerHTML=cardHTML(save.sel,me,mc).replace('class="pcard"','class="pcard" id="vL"');
 $('#vR').outerHTML=cardHTML(curRival.id,{lvl:curRival.lvl,st:curRival.st,mul:SKL[curDiff].stat},rc).replace('class="pcard"','class="pcard" id="vR"');
 show('#vs');curRival.col=rc;setTimeout(()=>{if($('#vs').classList.contains('hidden'))return;show(null);startMatch(curDiff,curRival)},2600)}
$('#b-again').onclick=()=>{$('#end').classList.add('hidden');curMode===3?(show(null),startMatch3()):beginVs()};
$('#b-menu').onclick=()=>{G=null;$('#hud').classList.add('hidden');$('#controls').classList.add('hidden');renderMenu()};
// ---- arranque ----
loadImgs().then(()=>{store();$('#b-snd').textContent=save.snd?'🔊':'🔇';renderMenu();requestAnimationFrame(loop)});
